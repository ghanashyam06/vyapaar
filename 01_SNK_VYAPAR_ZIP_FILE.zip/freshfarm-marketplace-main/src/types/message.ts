
export interface Contact {
  id: number;
  name: string;
  position: string;
  location: string;
  rating: number;
  lastMessage: string;
  time: string;
  unread: number;
  avatar: string;
  type: string;
  phone: string;
  email: string;
}

export interface Message {
  id: number;
  sender: string;
  content: string;
  time: string;
}
