
export interface Notification {
  id: number;
  type: 'message' | 'order' | 'verification' | 'system';
  title: string;
  content: string;
  time: string;
  read: boolean;
  sender?: string;
  senderImg?: string;
}
