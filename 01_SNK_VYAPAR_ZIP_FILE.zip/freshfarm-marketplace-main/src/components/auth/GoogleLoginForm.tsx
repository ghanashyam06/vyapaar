
import React from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

interface GoogleLoginFormProps {
  onSubmit: () => Promise<void>;
  isSubmitting: boolean;
}

const GoogleLoginForm: React.FC<GoogleLoginFormProps> = ({
  onSubmit,
  isSubmitting
}) => {
  return (
    <div className="space-y-6">
      <p className="text-sm text-center text-gray-600">
        Click the button below to log in with your Google account.
      </p>
      
      <Button
        onClick={onSubmit}
        disabled={isSubmitting}
        className="w-full bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 relative"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Connecting...
          </>
        ) : (
          <>
            <img 
              src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" 
              alt="Google" 
              className="w-5 h-5 mr-2" 
            />
            Continue with Google
          </>
        )}
      </Button>
    </div>
  );
};

export default GoogleLoginForm;
