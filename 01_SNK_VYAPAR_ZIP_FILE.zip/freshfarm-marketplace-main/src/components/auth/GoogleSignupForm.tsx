
import React from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';

interface GoogleSignupFormProps {
  onSubmit: () => Promise<void>;
  isSubmitting: boolean;
  acceptTerms: boolean;
  onTermsChange: (checked: boolean) => void;
}

const GoogleSignupForm: React.FC<GoogleSignupFormProps> = ({
  onSubmit,
  isSubmitting,
  acceptTerms,
  onTermsChange
}) => {
  return (
    <div className="space-y-6">
      <p className="text-sm text-center text-gray-600">
        Click the button below to sign up with your Google account.
      </p>
      
      <div className="flex items-start space-x-2 mb-4">
        <Checkbox 
          id="googleTerms" 
          checked={acceptTerms}
          onCheckedChange={(checked) => onTermsChange(checked as boolean)}
        />
        <label htmlFor="googleTerms" className="text-sm text-gray-600">
          I agree to the{' '}
          <a href="#" className="text-primary hover:text-primary/80">
            Terms of Service
          </a>{' '}
          and{' '}
          <a href="#" className="text-primary hover:text-primary/80">
            Privacy Policy
          </a>
        </label>
      </div>
      
      <Button
        onClick={onSubmit}
        disabled={isSubmitting || !acceptTerms}
        className="w-full bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
      >
        <img 
          src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" 
          alt="Google" 
          className="w-5 h-5 mr-2" 
        />
        {isSubmitting ? 'Connecting...' : 'Continue with Google'}
      </Button>
    </div>
  );
};

export default GoogleSignupForm;
