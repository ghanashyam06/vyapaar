
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Loader2, Phone } from 'lucide-react';

interface PhoneLoginFormProps {
  onSubmit: (phoneNumber: string) => Promise<void>;
  isSubmitting: boolean;
}

const PhoneLoginForm: React.FC<PhoneLoginFormProps> = ({
  onSubmit,
  isSubmitting
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isValidPhone, setIsValidPhone] = useState(true);

  const validatePhone = (phone: string) => {
    const phoneRegex = /^\+?[0-9]{10,15}$/;
    return phoneRegex.test(phone);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPhoneNumber(value);
    if (value) {
      setIsValidPhone(validatePhone(value));
    } else {
      setIsValidPhone(true);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phoneNumber) {
      toast.error('Please enter your phone number');
      return;
    }
    
    if (!validatePhone(phoneNumber)) {
      setIsValidPhone(false);
      toast.error('Please enter a valid phone number');
      return;
    }
    
    try {
      await onSubmit(phoneNumber);
    } catch (error) {
      console.error('Phone login error:', error);
      // Error handling is done in the auth context
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
          Phone Number
        </label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
          <Input
            id="phone"
            type="tel"
            value={phoneNumber}
            onChange={handlePhoneChange}
            placeholder="+91 1234567890"
            required
            className={`pl-10 ${!isValidPhone ? 'border-red-500 focus:ring-red-500' : ''}`}
          />
        </div>
        {!isValidPhone && (
          <p className="mt-1 text-xs text-red-500">
            Please enter a valid phone number (e.g., +91 1234567890)
          </p>
        )}
        <p className="mt-1 text-xs text-gray-500">
          We'll send you a verification code
        </p>
      </div>
      
      <div>
        <Button
          type="submit"
          disabled={isSubmitting || !isValidPhone}
          className="w-full"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Sending OTP...
            </>
          ) : (
            'Continue with Phone'
          )}
        </Button>
      </div>
    </form>
  );
};

export default PhoneLoginForm;
