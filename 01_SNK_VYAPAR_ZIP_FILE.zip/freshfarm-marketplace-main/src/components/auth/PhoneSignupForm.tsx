
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';

interface PhoneSignupFormProps {
  onSubmit: (name: string, phoneNumber: string) => Promise<void>;
  isSubmitting: boolean;
  acceptTerms: boolean;
  onTermsChange: (checked: boolean) => void;
}

const PhoneSignupForm: React.FC<PhoneSignupFormProps> = ({
  onSubmit,
  isSubmitting,
  acceptTerms,
  onTermsChange
}) => {
  const [phoneUserName, setPhoneUserName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phoneUserName || !phoneNumber) {
      toast.error('Please fill in all fields');
      return;
    }

    if (!acceptTerms) {
      toast.error('You must accept the Terms of Service and Privacy Policy');
      return;
    }
    
    // Basic phone validation
    const phoneRegex = /^\+?[0-9]{10,15}$/;
    if (!phoneRegex.test(phoneNumber)) {
      toast.error('Please enter a valid phone number');
      return;
    }
    
    await onSubmit(phoneUserName, phoneNumber);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="phoneUserName" className="block text-sm font-medium text-gray-700 mb-1">
          Full Name
        </label>
        <Input
          id="phoneUserName"
          type="text"
          value={phoneUserName}
          onChange={(e) => setPhoneUserName(e.target.value)}
          placeholder="Your full name"
          required
        />
      </div>
      
      <div>
        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
          Phone Number
        </label>
        <Input
          id="phone"
          type="tel"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          placeholder="+91 1234567890"
          required
        />
        <p className="mt-1 text-xs text-gray-500">
          We'll send you a verification code
        </p>
      </div>
      
      <div className="flex items-start space-x-2">
        <Checkbox 
          id="phoneTerms" 
          checked={acceptTerms}
          onCheckedChange={(checked) => onTermsChange(checked as boolean)}
        />
        <label htmlFor="phoneTerms" className="text-sm text-gray-600">
          I agree to the{' '}
          <a href="#" className="text-primary hover:text-primary/80">
            Terms of Service
          </a>{' '}
          and{' '}
          <a href="#" className="text-primary hover:text-primary/80">
            Privacy Policy
          </a>
        </label>
      </div>
      
      <div>
        <Button
          type="submit"
          disabled={isSubmitting || !acceptTerms}
          className="w-full"
        >
          {isSubmitting ? 'Sending OTP...' : 'Continue with Phone'}
        </Button>
      </div>
    </form>
  );
};

export default PhoneSignupForm;
