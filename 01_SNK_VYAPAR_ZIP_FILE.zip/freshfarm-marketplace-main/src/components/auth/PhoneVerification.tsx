
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Loader2 } from 'lucide-react';
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from '@/components/ui/input-otp';

interface PhoneVerificationProps {
  onBack: () => void;
}

const PhoneVerification: React.FC<PhoneVerificationProps> = ({ onBack }) => {
  const { verifyPhoneOTP, pendingPhoneNumber, isLoading, resetVerificationState, sendOTP } = useAuth();
  const [otp, setOtp] = useState('');
  const [resendDisabled, setResendDisabled] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const navigate = useNavigate();

  useEffect(() => {
    if (resendDisabled) {
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setResendDisabled(false);
            return 30;
          }
          return prev - 1;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [resendDisabled]);

  const handleVerify = async () => {
    if (!pendingPhoneNumber) {
      toast.error('No phone number to verify');
      return;
    }

    if (otp.length !== 6) {
      toast.error('Please enter a valid 6-digit OTP');
      return;
    }

    try {
      await verifyPhoneOTP(pendingPhoneNumber, otp);
      navigate('/');
    } catch (error) {
      console.error('Verification failed:', error);
      // Error is already handled in verifyPhoneOTP
    }
  };

  const handleResendOTP = async () => {
    if (!pendingPhoneNumber) {
      toast.error('No phone number to verify');
      return;
    }

    try {
      await sendOTP(pendingPhoneNumber);
      setResendDisabled(true);
      toast.success(`OTP resent to ${pendingPhoneNumber}`);
    } catch (error) {
      console.error('Failed to resend OTP:', error);
      // Error is already handled in sendOTP
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="mb-8">
        <button 
          onClick={() => {
            onBack();
            resetVerificationState();
          }}
          className="flex items-center gap-1.5 text-gray-600 hover:text-primary transition-colors"
        >
          <ArrowLeft size={18} />
          <span>Back</span>
        </button>
      </div>

      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold mb-2">Verify your phone number</h2>
        <p className="text-gray-600">
          We've sent a 6-digit code to{' '}
          <span className="font-medium">{pendingPhoneNumber}</span>
        </p>
      </div>

      <div className="mb-8">
        <div className="flex justify-center mb-6">
          <InputOTP
            maxLength={6}
            value={otp}
            onChange={setOtp}
            render={({ slots }) => (
              <InputOTPGroup>
                {slots && slots.map((slot, index) => (
                  <InputOTPSlot key={index} {...slot} index={index} />
                ))}
              </InputOTPGroup>
            )}
          />
        </div>

        <Button
          onClick={handleVerify}
          disabled={isLoading || otp.length !== 6}
          className="w-full mb-4"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Verifying...
            </>
          ) : (
            'Verify'
          )}
        </Button>

        <div className="text-center">
          <p className="text-sm text-gray-600 mb-2">
            Didn't receive the code?
          </p>
          <Button
            variant="ghost"
            onClick={handleResendOTP}
            disabled={isLoading || resendDisabled}
            className="text-primary hover:text-primary/80"
          >
            {resendDisabled 
              ? `Resend OTP in ${countdown}s` 
              : 'Resend OTP'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PhoneVerification;
