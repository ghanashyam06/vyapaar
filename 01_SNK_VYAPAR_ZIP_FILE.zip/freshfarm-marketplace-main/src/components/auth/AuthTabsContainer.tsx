
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Mail, Phone, Users } from 'lucide-react';

interface AuthTabsContainerProps {
  activeTab: string;
  onTabChange: (value: string) => void;
  children: React.ReactNode;
}

const AuthTabsContainer: React.FC<AuthTabsContainerProps> = ({
  activeTab,
  onTabChange,
  children
}) => {
  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="w-full mb-6">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="email" className="flex items-center gap-1.5">
          <Mail size={16} />
          <span>Email</span>
        </TabsTrigger>
        <TabsTrigger value="phone" className="flex items-center gap-1.5">
          <Phone size={16} />
          <span>Phone</span>
        </TabsTrigger>
        <TabsTrigger value="google" className="flex items-center gap-1.5">
          <Users size={16} />
          <span>Google</span>
        </TabsTrigger>
      </TabsList>

      {children}
    </Tabs>
  );
};

export default AuthTabsContainer;
