
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface ShelfLifeIndicatorProps {
  initialDays: number;
  currentDays: number;
  className?: string;
  showText?: boolean;
  showProgressBar?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const ShelfLifeIndicator = ({ 
  initialDays, 
  currentDays, 
  className,
  showText = true,
  showProgressBar = true,
  size = 'md'
}: ShelfLifeIndicatorProps) => {
  const [percentage, setPercentage] = useState(0);
  
  useEffect(() => {
    // Calculate percentage of shelf life remaining
    const calculated = Math.max(0, Math.min(100, (currentDays / initialDays) * 100));
    setPercentage(calculated);
  }, [initialDays, currentDays]);
  
  // Determine status color based on remaining shelf life percentage
  const getStatusColor = () => {
    if (percentage <= 0) return 'bg-fresh-danger text-white';
    if (percentage <= 30) return 'bg-fresh-danger/10 text-fresh-danger border-fresh-danger';
    if (percentage <= 60) return 'bg-fresh-warning/10 text-fresh-warning border-fresh-warning';
    return 'bg-fresh/10 text-fresh border-fresh';
  };
  
  // Determine progress bar color
  const getBarColor = () => {
    if (percentage <= 0) return 'bg-fresh-danger';
    if (percentage <= 30) return 'bg-fresh-danger';
    if (percentage <= 60) return 'bg-fresh-warning';
    return 'bg-fresh';
  };
  
  // Get text based on remaining days
  const getStatusText = () => {
    if (currentDays <= 0) return 'Expired';
    if (currentDays === 1) return '1 day left';
    return `${currentDays} days left`;
  };
  
  // Determine badge size
  const getBadgeSize = () => {
    switch (size) {
      case 'sm': return 'text-xs py-0.5 px-2';
      case 'lg': return 'text-sm py-1 px-3';
      default: return 'text-xs py-0.5 px-2.5';
    }
  };
  
  return (
    <div className={cn('flex flex-col gap-1', className)}>
      {showText && (
        <div 
          className={cn(
            'fresh-badge border',
            getBadgeSize(),
            getStatusColor()
          )}
        >
          {getStatusText()}
        </div>
      )}
      
      {showProgressBar && (
        <div className="shelf-life-indicator">
          <div 
            className={cn("shelf-life-indicator-bar", getBarColor())} 
            style={{ width: `${percentage}%` }}
          />
        </div>
      )}
    </div>
  );
};

export default ShelfLifeIndicator;
