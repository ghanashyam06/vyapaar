
import { useState } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SearchFiltersProps {
  onSearch: (params: SearchParams) => void;
  className?: string;
}

export interface SearchParams {
  query: string;
  category: string;
  priceRange: [number | null, number | null];
  location: string;
  shelfLife: number | null;
  sortBy: 'newest' | 'price-asc' | 'price-desc' | 'freshest';
}

const categories = [
  'All Categories',
  'Fruits',
  'Vegetables',
  'Grains',
  'Dairy & Produce',
  'Seeds',
  'Fertilizers',
  'Tools',
  'Equipment',
  'Others'
];

const shelfLifeOptions = [
  { label: 'Any', value: null },
  { label: 'Fresh (7+ days)', value: 7 },
  { label: 'Very Fresh (14+ days)', value: 14 },
  { label: 'Long Lasting (30+ days)', value: 30 }
];

const sortOptions = [
  { label: 'Newest First', value: 'newest' },
  { label: 'Price: Low to High', value: 'price-asc' },
  { label: 'Price: High to Low', value: 'price-desc' },
  { label: 'Freshest First', value: 'freshest' }
];

const SearchFilters = ({ onSearch, className }: SearchFiltersProps) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All Categories');
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [location, setLocation] = useState('');
  const [shelfLife, setShelfLife] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'freshest'>('newest');
  const [showFilters, setShowFilters] = useState(false);
  
  const handleSearch = () => {
    onSearch({
      query,
      category,
      priceRange: [minPrice ? Number(minPrice) : null, maxPrice ? Number(maxPrice) : null],
      location,
      shelfLife,
      sortBy
    });
  };
  
  const handleReset = () => {
    setQuery('');
    setCategory('All Categories');
    setMinPrice('');
    setMaxPrice('');
    setLocation('');
    setShelfLife(null);
    setSortBy('newest');
    
    onSearch({
      query: '',
      category: 'All Categories',
      priceRange: [null, null],
      location: '',
      shelfLife: null,
      sortBy: 'newest'
    });
  };
  
  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };
  
  return (
    <div className={cn('bg-white rounded-xl shadow-sm border border-gray-100', className)}>
      {/* Main search bar */}
      <div className="p-4 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products, tools, equipment..."
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        
        <button
          onClick={toggleFilters}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 px-4 py-2.5 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
        >
          <Filter size={18} />
          <span className="hidden sm:inline">Filters</span>
        </button>
        
        <button
          onClick={handleSearch}
          className="flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white px-5 py-2.5 rounded-lg transition-colors"
        >
          <span>Search</span>
        </button>
      </div>
      
      {/* Filters - conditionally render based on showFilters state */}
      <div className={cn(
        'overflow-hidden transition-all duration-300',
        showFilters ? 'max-h-[500px] border-t border-gray-200' : 'max-h-0'
      )}>
        <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Price Range (₹)</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                placeholder="Min"
                className="w-full p-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
              />
              <span className="text-gray-500">to</span>
              <input
                type="number"
                min="0"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                placeholder="Max"
                className="w-full p-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="City, State or District"
              className="w-full p-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Shelf Life</label>
            <select
              value={shelfLife?.toString() || ''}
              onChange={(e) => setShelfLife(e.target.value ? Number(e.target.value) : null)}
              className="w-full p-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
            >
              {shelfLifeOptions.map(option => (
                <option key={option.label} value={option.value?.toString() || ''}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full p-2.5 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
            >
              {sortOptions.map(option => (
                <option key={option.label} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-end">
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 text-gray-600 hover:text-gray-900 px-4 py-2.5 hover:bg-gray-50 rounded-lg transition-colors"
            >
              <X size={16} />
              <span>Reset Filters</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;
