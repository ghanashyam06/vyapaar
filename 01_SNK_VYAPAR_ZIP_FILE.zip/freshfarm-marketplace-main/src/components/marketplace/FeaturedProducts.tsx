
import { useEffect, useState } from 'react';
import ProductCard, { Product } from './ProductCard';

interface FeaturedProductsProps {
  title?: string;
  subtitle?: string;
}

// This is mock data - in a real app, you'd fetch this from an API
const mockProducts: Product[] = [
  {
    id: '1',
    title: 'Fresh Organic Mangoes (Alphonso)',
    price: 1200,
    negotiable: true,
    location: 'Ratnagiri, Maharashtra',
    category: 'Fruits',
    shelfLife: 7,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Premium quality Alphonso mangoes directly from our farm. Sweet and perfect ripeness.',
    images: ['https://images.unsplash.com/photo-1553279768-865429fa0078?q=80&w=1374&auto=format&fit=crop'],
    sellerName: 'Raj Farms'
  },
  {
    id: '2',
    title: 'Organic Rice (10kg)',
    price: 850,
    negotiable: false,
    location: 'Basmati Belt, Punjab',
    category: 'Grains',
    shelfLife: 180,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Finest quality basmati rice, organically grown without pesticides.',
    images: ['https://images.unsplash.com/photo-1586201375761-83865001e8ac?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Punjab Organics'
  },
  {
    id: '3',
    title: 'Fresh Farm Tomatoes',
    price: 60,
    negotiable: true,
    location: 'Nashik, Maharashtra',
    category: 'Vegetables',
    shelfLife: 5,
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Fresh red tomatoes picked this morning. Perfect for salads and cooking.',
    images: ['https://images.unsplash.com/photo-1592924357520-e34c487e3c6c?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Green Valley'
  },
  {
    id: '4',
    title: 'Fresh Coconuts (10 pcs)',
    price: 350,
    negotiable: false,
    location: 'Kochi, Kerala',
    category: 'Fruits',
    shelfLife: 30,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Young tender coconuts, perfect for drinking and eating the soft kernel.',
    images: ['https://images.unsplash.com/photo-1544681280-d23a28c28c80?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Kerala Coconut Farms'
  },
  {
    id: '5',
    title: 'Organic Honey (1kg)',
    price: 650,
    negotiable: false,
    location: 'Coorg, Karnataka',
    category: 'Dairy & Produce',
    shelfLife: 365,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Pure organic honey collected from our bee farms in Coorg. No additives or sugar.',
    images: ['https://images.unsplash.com/photo-1587049352851-8d4e89133924?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Honey Heaven'
  }
];

const FeaturedProducts = ({ title = "Featured Products", subtitle }: FeaturedProductsProps) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate API call with setTimeout
    const timer = setTimeout(() => {
      setProducts(mockProducts);
      setIsLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <section className="py-10 relative">
      {/* Seasonal crops background */}
      <div className="absolute inset-0 z-0 opacity-5">
        <img 
          src="https://images.unsplash.com/photo-1620706857370-e1b9770e8bb1?q=80&w=1464&auto=format&fit=crop" 
          alt="Seasonal crops background" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="relative z-10">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-2">{title}</h2>
          {subtitle && <p className="text-gray-600 max-w-2xl mx-auto">{subtitle}</p>}
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="marketplace-card animate-pulse">
                <div className="aspect-[4/3] bg-gray-200"></div>
                <div className="p-4">
                  <div className="h-5 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <ProductCard 
                key={product.id} 
                product={product}
                featured={index === 0}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default FeaturedProducts;
