
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Upload, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ProductFormProps {
  className?: string;
}

const categories = [
  'Fruits',
  'Vegetables',
  'Grains',
  'Dairy & Produce',
  'Seeds',
  'Fertilizers',
  'Tools',
  'Equipment',
  'Others'
];

const ProductForm = ({ className }: ProductFormProps) => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [negotiable, setNegotiable] = useState(false);
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState('');
  const [shelfLife, setShelfLife] = useState('');
  const [description, setDescription] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    // Check if adding these files would exceed the 5 image limit
    if (images.length + files.length > 5) {
      toast.error('You can upload a maximum of 5 images');
      return;
    }
    
    // Process each file
    Array.from(files).forEach(file => {
      // Create a local URL for the image
      const imageUrl = URL.createObjectURL(file);
      setImages(prev => [...prev, imageUrl]);
    });
  };
  
  const removeImage = (indexToRemove: number) => {
    setImages(prev => prev.filter((_, index) => index !== indexToRemove));
  };
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!title.trim()) newErrors.title = 'Title is required';
    if (!price.trim()) newErrors.price = 'Price is required';
    else if (isNaN(Number(price)) || Number(price) <= 0) newErrors.price = 'Price must be a positive number';
    if (!location.trim()) newErrors.location = 'Location is required';
    if (!category) newErrors.category = 'Category is required';
    if (!shelfLife.trim()) newErrors.shelfLife = 'Shelf life is required';
    else if (isNaN(Number(shelfLife)) || Number(shelfLife) <= 0) newErrors.shelfLife = 'Shelf life must be a positive number';
    if (!description.trim()) newErrors.description = 'Description is required';
    if (images.length === 0) newErrors.images = 'At least one image is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    setIsSubmitting(true);
    
    try {
      // In a real app, you would send this data to your API
      console.log({
        title,
        price: Number(price),
        negotiable,
        location,
        category,
        shelfLife: Number(shelfLife),
        description,
        images,
        createdAt: new Date().toISOString(),
      });
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast.success('Your listing has been created successfully!');
      navigate('/marketplace');
    } catch (error) {
      toast.error('Failed to create listing. Please try again.');
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className={cn('space-y-8', className)}>
      <div className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
            Title *
          </label>
          <input
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Fresh Organic Mangoes for Sale"
            className={cn(
              'w-full p-3 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition',
              errors.title && 'border-fresh-danger focus:border-fresh-danger focus:ring-fresh-danger'
            )}
          />
          {errors.title && (
            <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
              <AlertCircle size={14} />
              {errors.title}
            </p>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
              Price (₹) *
            </label>
            <div className="relative">
              <input
                id="price"
                type="text"
                inputMode="numeric"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Enter price in INR"
                className={cn(
                  'w-full p-3 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition',
                  errors.price && 'border-fresh-danger focus:border-fresh-danger focus:ring-fresh-danger'
                )}
              />
              <div className="mt-2 flex items-center">
                <input
                  id="negotiable"
                  type="checkbox"
                  checked={negotiable}
                  onChange={(e) => setNegotiable(e.target.checked)}
                  className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                />
                <label htmlFor="negotiable" className="ml-2 text-sm text-gray-600">
                  Price is negotiable
                </label>
              </div>
            </div>
            {errors.price && (
              <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.price}
              </p>
            )}
          </div>
          
          <div>
            <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
              Location *
            </label>
            <input
              id="location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="City, State or District"
              className={cn(
                'w-full p-3 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition',
                errors.location && 'border-fresh-danger focus:border-fresh-danger focus:ring-fresh-danger'
              )}
            />
            {errors.location && (
              <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.location}
              </p>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
              Category *
            </label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className={cn(
                'w-full p-3 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition',
                errors.category && 'border-fresh-danger focus:border-fresh-danger focus:ring-fresh-danger'
              )}
            >
              <option value="" disabled>Select a category</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {errors.category && (
              <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.category}
              </p>
            )}
          </div>
          
          <div>
            <label htmlFor="shelfLife" className="block text-sm font-medium text-gray-700 mb-1">
              Shelf Life (days) *
            </label>
            <input
              id="shelfLife"
              type="text"
              inputMode="numeric"
              value={shelfLife}
              onChange={(e) => setShelfLife(e.target.value)}
              placeholder="How many days will this product remain fresh?"
              className={cn(
                'w-full p-3 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition',
                errors.shelfLife && 'border-fresh-danger focus:border-fresh-danger focus:ring-fresh-danger'
              )}
            />
            {errors.shelfLife && (
              <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.shelfLife}
              </p>
            )}
          </div>
        </div>
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
            Description *
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe your product, its quality, and any other important details..."
            rows={4}
            className={cn(
              'w-full p-3 rounded-lg border border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition',
              errors.description && 'border-fresh-danger focus:border-fresh-danger focus:ring-fresh-danger'
            )}
          />
          {errors.description && (
            <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
              <AlertCircle size={14} />
              {errors.description}
            </p>
          )}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Images * (Max 5)
          </label>
          <div className="flex flex-wrap gap-4 mt-2">
            {images.map((image, index) => (
              <div 
                key={index} 
                className="relative w-24 h-24 border border-gray-200 rounded-lg overflow-hidden group"
              >
                <img 
                  src={image} 
                  alt={`Preview ${index + 1}`} 
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => removeImage(index)}
                  className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={20} className="text-white" />
                </button>
              </div>
            ))}
            
            {images.length < 5 && (
              <label className="flex flex-col items-center justify-center w-24 h-24 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload size={20} className="text-gray-400 mb-1" />
                  <p className="text-xs text-gray-500">Upload</p>
                </div>
                <input 
                  type="file" 
                  className="hidden"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                />
              </label>
            )}
          </div>
          {errors.images && (
            <p className="mt-1 text-sm text-fresh-danger flex items-center gap-1">
              <AlertCircle size={14} />
              {errors.images}
            </p>
          )}
          <p className="mt-2 text-xs text-gray-500">
            Upload up to 5 clear images of your product. First image will be the featured image.
          </p>
        </div>
      </div>
      
      <div className="flex justify-end gap-4">
        <button
          type="button"
          onClick={() => navigate('/marketplace')}
          className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className={cn(
            'px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-70',
            isSubmitting && 'opacity-70 cursor-not-allowed'
          )}
        >
          {isSubmitting ? 'Creating Listing...' : 'Create Listing'}
        </button>
      </div>
    </form>
  );
};

export default ProductForm;
