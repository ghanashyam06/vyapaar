
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, Shield, Award, Heart, Share2 } from 'lucide-react';
import ShelfLifeIndicator from './ShelfLifeIndicator';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from 'sonner';

export interface Product {
  id: string;
  title: string;
  price: number;
  negotiable: boolean;
  location: string;
  category: string;
  shelfLife: number;
  createdAt: string;
  description: string;
  images: string[];
  sellerName: string;
  sellerAvatar?: string;
  verifiedFarmer?: boolean;
  rating?: number;
  organicCertified?: boolean;
  origin?: string;
  weight?: string;
  stockQuantity?: number;
  harvestDate?: string;
  nutritionalInfo?: string;
  phone?: string;
}

interface ProductCardProps {
  product: Product;
  featured?: boolean;
  className?: string;
}

const ProductCard = ({ product, featured = false, className }: ProductCardProps) => {
  const [daysRemaining, setDaysRemaining] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  
  useEffect(() => {
    // Check if this product is saved in local storage
    const savedProducts = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    setIsSaved(savedProducts.includes(product.id));
    
    // Calculate the days remaining based on creation date and shelf life
    const creationDate = new Date(product.createdAt);
    const currentDate = new Date();
    const daysPassed = Math.floor((currentDate.getTime() - creationDate.getTime()) / (1000 * 60 * 60 * 24));
    const remaining = Math.max(0, product.shelfLife - daysPassed);
    setDaysRemaining(remaining);
  }, [product.createdAt, product.shelfLife, product.id]);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };
  
  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation to product detail
    e.stopPropagation(); // Stop event propagation
    
    // Get saved products from local storage
    const savedProducts = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    
    if (isSaved) {
      // Remove product from saved list
      const updatedSavedProducts = savedProducts.filter((id: string) => id !== product.id);
      localStorage.setItem('savedProducts', JSON.stringify(updatedSavedProducts));
      setIsSaved(false);
      toast.success('Product removed from saved items');
    } else {
      // Add product to saved list
      savedProducts.push(product.id);
      localStorage.setItem('savedProducts', JSON.stringify(savedProducts));
      setIsSaved(true);
      toast.success('Product saved successfully');
    }
  };
  
  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation to product detail
    e.stopPropagation(); // Stop event propagation
    
    // Enhanced share functionality with fallback
    try {
      // Create share data object
      const shareData = {
        title: product.title,
        text: `Check out this product: ${product.title}`,
        url: window.location.origin + `/product/${product.id}`,
      };
      
      // Try using the Web Share API if available
      if (navigator.share) {
        navigator.share(shareData)
          .then(() => toast.success('Shared successfully'))
          .catch((error) => {
            console.error('Error sharing', error);
            // Fallback to clipboard if share fails
            navigator.clipboard.writeText(window.location.origin + `/product/${product.id}`)
              .then(() => toast.success('Link copied to clipboard'))
              .catch(() => toast.error('Failed to copy link'));
          });
      } else {
        // Fallback for browsers that don't support the Web Share API
        navigator.clipboard.writeText(window.location.origin + `/product/${product.id}`)
          .then(() => toast.success('Link copied to clipboard'))
          .catch(() => toast.error('Failed to copy link'));
      }
    } catch (error) {
      console.error('Error sharing', error);
      toast.error('Failed to share product');
    }
  };
  
  return (
    <Link 
      to={`/product/${product.id}`} 
      className={cn(
        'marketplace-card group animate-fade-in hover-scale relative',
        featured ? 'md:col-span-2 md:row-span-2' : '',
        className
      )}
    >
      <div className="image-container">
        <img 
          src={product.images[0]} 
          alt={product.title}
          className="w-full h-full object-cover transition-transform duration-500"
          loading="lazy"
        />
        {product.negotiable && (
          <div className="absolute top-3 right-3 bg-black/70 text-white text-xs font-medium px-2 py-1 rounded">
            Negotiable
          </div>
        )}
        {product.verifiedFarmer && (
          <div className="absolute top-3 left-3 bg-premium-green/90 text-white text-xs font-medium px-2 py-1 rounded-full flex items-center gap-1">
            <Shield size={12} />
            <span>Verified</span>
          </div>
        )}
        {product.organicCertified && (
          <div className="absolute bottom-3 left-3 bg-premium-green/90 text-white text-xs font-medium px-2 py-1 rounded-full flex items-center gap-1">
            <Award size={12} />
            <span>Organic</span>
          </div>
        )}
        
        {/* Action buttons */}
        <div className="absolute bottom-3 right-3 flex gap-2">
          <button 
            onClick={handleSave}
            className="p-2 bg-white/90 hover:bg-white rounded-full shadow-sm transition-colors"
            aria-label={isSaved ? "Remove from saved" : "Save product"}
          >
            <Heart 
              size={16} 
              className={isSaved ? "fill-red-500 text-red-500" : "text-gray-700"} 
            />
          </button>
          
          <button 
            onClick={handleShare}
            className="p-2 bg-white/90 hover:bg-white rounded-full shadow-sm transition-colors"
            aria-label="Share product"
          >
            <Share2 size={16} className="text-gray-700" />
          </button>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start gap-2 mb-2">
          <h3 className="font-medium text-lg line-clamp-1 group-hover:text-premium-green transition-colors">
            {product.title}
          </h3>
          <span className="font-semibold text-lg whitespace-nowrap">
            {formatPrice(product.price)}
          </span>
        </div>
        
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <MapPin size={14} className="mr-1 flex-shrink-0" />
          <span className="line-clamp-1">{product.location}</span>
        </div>

        {product.weight && (
          <div className="text-xs text-gray-500 mb-2">
            Weight: {product.weight}
          </div>
        )}
        
        <div className="flex justify-between items-center">
          <div className="flex items-center text-xs text-gray-500">
            <Calendar size={14} className="mr-1 flex-shrink-0" />
            <span>
              {new Date(product.createdAt).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric'
              })}
            </span>
          </div>
          
          <ShelfLifeIndicator
            initialDays={product.shelfLife}
            currentDays={daysRemaining}
            size="sm"
          />
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
