
import { useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Phone, Info, MoreVertical, ChevronLeft } from 'lucide-react';
import MessageInput from './MessageInput';

interface Message {
  id: number;
  sender: string;
  content: string;
  time: string;
}

interface Contact {
  id: number;
  name: string;
  position: string;
  location: string;
  avatar: string;
  type: string;
}

interface ChatAreaProps {
  contact: Contact;
  messages: Message[];
  isSending: boolean;
  onSendMessage: (message: string) => void;
  onBackToContacts: () => void;
  onToggleProfile: () => void;
}

const ChatArea = ({ 
  contact, 
  messages, 
  isSending, 
  onSendMessage, 
  onBackToContacts, 
  onToggleProfile 
}: ChatAreaProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  return (
    <div className="col-span-2 flex flex-col">
      {/* Chat Header */}
      <div className="p-3 border-b flex items-center justify-between bg-white">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="icon"
            className="md:hidden"
            onClick={onBackToContacts}
            aria-label="Back to contacts"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center cursor-pointer" onClick={onToggleProfile}>
            <Avatar className="h-10 w-10 mr-3">
              {contact.avatar ? (
                <AvatarImage src={contact.avatar} alt={contact.name} className="h-full w-full object-cover" />
              ) : (
                <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
              )}
            </Avatar>
            
            <div>
              <p className="font-medium">{contact.name}</p>
              <p className="text-xs text-gray-500">
                {contact.type === 'seller' ? 'Seller' : 'Customer Support'} • {contact.location}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex space-x-1">
          <Button variant="ghost" size="icon" aria-label="Call">
            <Phone className="h-5 w-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onToggleProfile}
            aria-label="View profile"
          >
            <Info className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" aria-label="More options">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Messages */}
      <ScrollArea className="flex-1 p-4 bg-gray-50">
        <div className="space-y-3">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex ${message.sender === 'me' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[75%] p-3 rounded-lg animate-scale-in ${
                  message.sender === 'me' 
                    ? 'bg-premium-green text-white rounded-tr-none' 
                    : 'bg-white rounded-tl-none'
                }`}
              >
                <p>{message.content}</p>
                <p className={`text-xs mt-1 ${
                  message.sender === 'me' ? 'text-green-100' : 'text-gray-500'
                }`}>
                  {message.time}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      
      {/* Input Area */}
      <MessageInput onSendMessage={onSendMessage} isSending={isSending} />
    </div>
  );
};

export default ChatArea;
