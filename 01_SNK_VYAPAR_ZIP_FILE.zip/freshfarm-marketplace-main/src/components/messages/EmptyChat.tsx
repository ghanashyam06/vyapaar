
import { MessageSquare } from 'lucide-react';

const EmptyChat = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-4">
      <div className="h-20 w-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
        <MessageSquare className="h-10 w-10 text-gray-400" />
      </div>
      <h3 className="text-xl font-medium mb-2">Your Messages</h3>
      <p className="text-gray-500 max-w-md">
        Select a conversation from the left to start chatting with sellers and customer support.
      </p>
    </div>
  );
};

export default EmptyChat;
