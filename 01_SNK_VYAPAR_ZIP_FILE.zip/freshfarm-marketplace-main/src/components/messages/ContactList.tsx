
import { useState } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Contact {
  id: number;
  name: string;
  position: string;
  location: string;
  rating: number;
  lastMessage: string;
  time: string;
  unread: number;
  avatar: string;
  type: string;
  phone: string;
  email: string;
}

interface ContactListProps {
  contacts: Contact[];
  selectedContact: Contact | null;
  onSelectContact: (contact: Contact) => void;
}

const ContactList = ({ contacts, selectedContact, onSelectContact }: ContactListProps) => {
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Apply filters and search
  const filteredContacts = contacts.filter(contact => {
    const matchesTab = activeTab === 'all' || contact.type === activeTab;
    const matchesSearch = contact.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  return (
    <div className="border-r">
      <div className="p-4 border-b bg-gray-50">
        <h2 className="text-xl font-bold mb-4">Messages</h2>
        
        <div className="relative mb-3">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search contacts..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full">
            <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
            <TabsTrigger value="seller" className="flex-1">Sellers</TabsTrigger>
            <TabsTrigger value="support" className="flex-1">Support</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      <ScrollArea className="h-[calc(75vh-135px)]">
        {filteredContacts.length > 0 ? (
          filteredContacts.map((contact) => (
            <div 
              key={contact.id}
              className={`p-3 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                selectedContact?.id === contact.id ? 'bg-gray-100' : ''
              }`}
              onClick={() => onSelectContact(contact)}
            >
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Avatar className="h-12 w-12">
                    {contact.avatar ? (
                      <AvatarImage src={contact.avatar} alt={contact.name} />
                    ) : (
                      <AvatarFallback>
                        {contact.name.charAt(0)}
                      </AvatarFallback>
                    )}
                    {contact.unread > 0 && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center">
                        {contact.unread}
                      </Badge>
                    )}
                  </Avatar>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <p className="font-medium truncate">{contact.name}</p>
                    <span className="text-xs text-gray-500">{contact.time}</span>
                  </div>
                  <p className={`text-sm truncate ${
                    contact.unread > 0 ? 'font-medium text-gray-900' : 'text-gray-500'
                  }`}>
                    {contact.lastMessage}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="p-4 text-center text-gray-500">
            No contacts found
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default ContactList;
