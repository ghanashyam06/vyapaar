
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Phone, MessageSquare, Info, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Contact {
  id: number;
  name: string;
  position: string;
  location: string;
  rating: number;
  avatar: string;
  type: string;
  phone: string;
  email: string;
}

interface ProfileViewProps {
  contact: Contact;
  onBack: () => void;
}

const ProfileView = ({ contact, onBack }: ProfileViewProps) => {
  const navigate = useNavigate();

  return (
    <div className="col-span-2 flex flex-col">
      <div className="p-3 border-b flex items-center justify-between bg-white">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            aria-label="Back to chat"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h3 className="font-semibold">Profile Details</h3>
        </div>
      </div>
      
      <ScrollArea className="flex-1 p-4">
        <div className="flex flex-col items-center text-center mb-6">
          <Avatar className="h-24 w-24 mb-3">
            {contact.avatar ? (
              <AvatarImage src={contact.avatar} alt={contact.name} />
            ) : (
              <AvatarFallback className="text-2xl">
                {contact.name.charAt(0)}
              </AvatarFallback>
            )}
          </Avatar>
          <h2 className="text-xl font-bold">{contact.name}</h2>
          <p className="text-gray-600">{contact.position}</p>
          <div className="flex items-center mt-1">
            <span className="text-yellow-500">★</span>
            <span className="ml-1">{contact.rating}</span>
          </div>
        </div>
        
        <Card className="mb-4 p-4">
          <h3 className="font-semibold mb-3">Contact Information</h3>
          <div className="space-y-3">
            <div className="flex items-center">
              <Phone className="h-5 w-5 mr-3 text-gray-500" />
              <span>{contact.phone}</span>
            </div>
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-3 text-gray-500" />
              <span>{contact.email}</span>
            </div>
            <div className="flex items-center">
              <Info className="h-5 w-5 mr-3 text-gray-500" />
              <span>{contact.location}</span>
            </div>
          </div>
        </Card>
        
        {contact.type === 'seller' && (
          <Card className="mb-4 p-4">
            <h3 className="font-semibold mb-3">Seller Information</h3>
            <p className="text-gray-600 mb-2">
              Provides products in the following categories:
            </p>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">Vegetables</Badge>
              <Badge variant="outline">Fruits</Badge>
              {contact.id === 4 && <Badge variant="outline">Grains</Badge>}
            </div>
          </Card>
        )}
        
        <div className="flex justify-between mt-4">
          <Button variant="outline" onClick={onBack}>
            Back to Chat
          </Button>
          {contact.type === 'seller' && (
            <Button onClick={() => navigate('/marketplace')}>
              View Products
            </Button>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ProfileView;
