
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Notification } from '@/types/notification';
import { NotificationCard } from './NotificationCard';
import { EmptyNotifications } from './EmptyNotifications';

interface NotificationTabsProps {
  notifications: Notification[];
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadCount: number;
  onMarkAsRead: (id: number) => void;
  onDelete: (id: number) => void;
  onNotificationClick: (notification: Notification) => void;
}

export const NotificationTabs = ({ 
  notifications, 
  activeTab, 
  setActiveTab, 
  unreadCount, 
  onMarkAsRead, 
  onDelete, 
  onNotificationClick 
}: NotificationTabsProps) => {
  
  const filteredNotifications = notifications.filter(notification => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !notification.read;
    return notification.type === activeTab;
  });
  
  return (
    <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="mb-4">
        <TabsTrigger value="all">
          All
          {notifications.length > 0 && (
            <Badge variant="secondary" className="ml-2">{notifications.length}</Badge>
          )}
        </TabsTrigger>
        <TabsTrigger value="unread">
          Unread
          {unreadCount > 0 && (
            <Badge variant="secondary" className="ml-2">{unreadCount}</Badge>
          )}
        </TabsTrigger>
        <TabsTrigger value="message">Messages</TabsTrigger>
        <TabsTrigger value="order">Orders</TabsTrigger>
        <TabsTrigger value="verification">Verification</TabsTrigger>
      </TabsList>
      
      <TabsContent value={activeTab} className="space-y-4">
        {filteredNotifications.length > 0 ? (
          filteredNotifications.map((notification) => (
            <NotificationCard
              key={notification.id}
              notification={notification}
              onMarkAsRead={onMarkAsRead}
              onDelete={onDelete}
              onClick={onNotificationClick}
            />
          ))
        ) : (
          <EmptyNotifications />
        )}
      </TabsContent>
    </Tabs>
  );
};
