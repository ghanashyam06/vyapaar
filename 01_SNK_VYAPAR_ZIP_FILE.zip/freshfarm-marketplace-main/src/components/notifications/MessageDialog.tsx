
import { User, Send } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Notification } from '@/types/notification';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';

interface MessageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedMessage: Notification | null;
}

export const MessageDialog = ({ open, onOpenChange, selectedMessage }: MessageDialogProps) => {
  const [replyText, setReplyText] = useState('');
  
  const handleSendReply = () => {
    if (!replyText.trim()) {
      toast.error('Please enter a message');
      return;
    }
    
    // In a real app, this would send the reply to the API
    toast.success(`Reply sent to ${selectedMessage?.sender}`);
    setReplyText('');
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Message from {selectedMessage?.sender}</DialogTitle>
          <DialogDescription>
            {selectedMessage?.time}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex items-start space-x-4 pt-4">
          <div className="h-10 w-10 rounded-full bg-gray-200 overflow-hidden">
            {selectedMessage?.senderImg ? (
              <img 
                src={selectedMessage.senderImg} 
                alt={selectedMessage.sender} 
                className="h-full w-full object-cover"
              />
            ) : (
              <User className="h-6 w-6 m-2 text-gray-500" />
            )}
          </div>
          <div className="flex-1">
            <p className="text-sm text-gray-800">
              {selectedMessage?.content}
            </p>
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex flex-col space-y-1.5">
            <label htmlFor="replyMessage" className="text-sm font-medium">
              Your reply
            </label>
            <div className="flex gap-2">
              <Textarea
                id="replyMessage"
                placeholder="Type your reply here..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                className="flex-1"
              />
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            className="mt-4"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSendReply}
            className="mt-4"
            disabled={!replyText.trim()}
          >
            <Send className="mr-2 h-4 w-4" />
            Send Reply
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
