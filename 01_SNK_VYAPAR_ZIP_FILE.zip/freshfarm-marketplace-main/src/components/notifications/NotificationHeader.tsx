
import { Button } from '@/components/ui/button';

interface NotificationHeaderProps {
  unreadCount: number;
  onMarkAllAsRead: () => void;
  onClearAll: () => void;
}

export const NotificationHeader = ({ 
  unreadCount, 
  onMarkAllAsRead, 
  onClearAll 
}: NotificationHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-6">
      <div>
        <h1 className="text-2xl font-bold">Notifications</h1>
        <p className="text-gray-500">{unreadCount} unread notifications</p>
      </div>
      <div className="flex gap-2">
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={onMarkAllAsRead}>
            Mark all as read
          </Button>
        )}
        <Button variant="outline" size="sm" onClick={onClearAll}>
          Clear all
        </Button>
      </div>
    </div>
  );
};
