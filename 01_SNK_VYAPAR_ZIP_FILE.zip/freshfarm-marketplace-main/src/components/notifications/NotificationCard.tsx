
import { useState } from 'react';
import { Bell, X, MessageSquare, ShoppingBag, Shield, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Notification } from '@/types/notification';
import { useNavigate } from 'react-router-dom';

interface NotificationCardProps {
  notification: Notification;
  onMarkAsRead: (id: number) => void;
  onDelete: (id: number) => void;
  onClick: (notification: Notification) => void;
}

export const NotificationCard = ({ 
  notification, 
  onMarkAsRead, 
  onDelete, 
  onClick 
}: NotificationCardProps) => {
  const navigate = useNavigate();
  
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'message':
        return <MessageSquare className="h-5 w-5 text-blue-500" />;
      case 'order':
        return <ShoppingBag className="h-5 w-5 text-green-500" />;
      case 'verification':
        return <Shield className="h-5 w-5 text-purple-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const handleClick = () => {
    // Mark as read when clicked
    if (!notification.read) {
      onMarkAsRead(notification.id);
    }
    
    // If it's a message notification, redirect to messages page
    if (notification.type === 'message') {
      navigate('/messages');
    } else {
      // For other notification types, use the default click handler
      onClick(notification);
    }
  };

  return (
    <Card 
      key={notification.id} 
      className={`p-4 relative ${!notification.read ? 'border-l-4 border-l-primary' : ''} 
        ${notification.type === 'message' ? 'cursor-pointer hover:bg-gray-50' : ''}`}
      onClick={handleClick}
    >
      <div className="flex">
        <div className="mr-3 mt-1">
          {getNotificationIcon(notification.type)}
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className={`font-medium ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
              {notification.title}
            </h3>
            <div className="flex items-center gap-2">
              {!notification.read && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onMarkAsRead(notification.id);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                  aria-label="Mark as read"
                >
                  <Badge variant="outline" className="h-5 px-1.5 text-[10px]">
                    Mark as read
                  </Badge>
                </button>
              )}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(notification.id);
                }}
                className="text-gray-400 hover:text-gray-600"
                aria-label="Delete notification"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
          <p className={`text-sm mt-1 ${!notification.read ? 'text-gray-800' : 'text-gray-600'}`}>
            {notification.content}
          </p>
          <div className="flex items-center mt-2 text-xs text-gray-500">
            <Clock className="h-3 w-3 mr-1" />
            {notification.time}
          </div>
        </div>
      </div>
    </Card>
  );
};
