
import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingBag, Bell, Search, User, LogOut, MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'sonner';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [hasNotification, setHasNotification] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  
  const { user, logout, isAuthenticated } = useAuth();
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  useEffect(() => {
    // Close mobile menu when route changes
    setMobileMenuOpen(false);
    setProfileMenuOpen(false);
    setShowSearchInput(false);
  }, [location.pathname]);
  
  useEffect(() => {
    // Simulate notification for demo purposes
    const timer = setTimeout(() => {
      if (isAuthenticated) {
        setHasNotification(true);
        playNotificationSound();
        toast.info("You have a new message", {
          description: "Someone is interested in your products"
        });
      }
    }, 10000);
    return () => clearTimeout(timer);
  }, [isAuthenticated]);
  
  const playNotificationSound = () => {
    const audio = new Audio('/notification-sound.mp3');
    audio.play().catch(err => console.error("Audio play error:", err));
  };
  
  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Marketplace', path: '/marketplace' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];
  
  const handleLogout = () => {
    logout();
    toast.success('You have been logged out successfully');
    navigate('/');
  };
  
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/marketplace?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setShowSearchInput(false);
    }
  };
  
  const handleNotificationClick = () => {
    setHasNotification(false);
    navigate('/notifications');
  };
  
  const handleMessagesClick = () => {
    navigate('/messages');
  };
  
  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 backdrop-blur-md border-b',
        isScrolled 
          ? 'bg-white/90 border-gray-200' 
          : 'bg-transparent border-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0 font-bold text-2xl flex items-center gap-2">
            <Link to="/" className="flex items-center gap-2">
              <img 
                src="/lovable-uploads/744f011d-f81d-4fbb-ab7e-eb7db06d4e17.png" 
                alt="SNK Vyapar Logo" 
                className="h-10 w-10 rounded-full"
              />
              SNK <span className="text-primary">Vyapar</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navLinks.map(link => (
              <Link
                key={link.name}
                to={link.path}
                className={cn(
                  'transition-colors text-gray-600 hover:text-primary relative py-2',
                  location.pathname === link.path && 'text-primary font-medium',
                  location.pathname === link.path && 'after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-primary after:rounded-full'
                )}
              >
                {link.name}
              </Link>
            ))}
          </nav>
          
          {/* Desktop Action Buttons */}
          <div className="hidden md:flex items-center space-x-5">
            <div className="relative">
              {showSearchInput ? (
                <form onSubmit={handleSearchSubmit} className="absolute right-0 top-0 flex items-center">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-60 border border-gray-300 rounded-l-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary"
                    placeholder="Search products..."
                    autoFocus
                  />
                  <button 
                    type="submit" 
                    className="bg-primary text-white p-2 rounded-r-lg hover:bg-primary/90"
                  >
                    <Search size={16} />
                  </button>
                  <button 
                    type="button"
                    onClick={() => setShowSearchInput(false)}
                    className="ml-2 text-gray-500 hover:text-gray-700"
                  >
                    <X size={16} />
                  </button>
                </form>
              ) : (
                <button 
                  className="text-gray-600 hover:text-primary transition-colors" 
                  aria-label="Search"
                  onClick={() => setShowSearchInput(true)}
                >
                  <Search size={20} />
                </button>
              )}
            </div>
            
            <div className="relative">
              <button 
                className="text-gray-600 hover:text-primary transition-colors relative" 
                aria-label="Notifications"
                onClick={handleNotificationClick}
              >
                <Bell size={20} />
                {hasNotification && (
                  <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full animate-pulse" />
                )}
              </button>
            </div>
            
            {isAuthenticated && (
              <div className="relative">
                <button 
                  className="text-gray-600 hover:text-primary transition-colors" 
                  aria-label="Messages"
                  onClick={handleMessagesClick}
                >
                  <MessageSquare size={20} />
                </button>
              </div>
            )}
            
            {isAuthenticated ? (
              <>
                <Link 
                  to="/create-listing" 
                  className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
                >
                  Sell Item
                </Link>
                <div className="relative">
                  <button 
                    onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                    className="text-gray-600 hover:text-primary transition-colors rounded-full border border-gray-200 p-1.5 overflow-hidden" 
                    aria-label="Profile"
                  >
                    {user?.profilePicture ? (
                      <img 
                        src={user.profilePicture} 
                        alt={user.name}
                        className="w-6 h-6 rounded-full object-cover"
                      />
                    ) : (
                      <User size={18} />
                    )}
                  </button>
                  
                  {/* Profile dropdown */}
                  {profileMenuOpen && (
                    <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
                      <div className="py-1">
                        <div className="px-4 py-2 text-sm text-gray-700 border-b border-gray-100">
                          <div className="font-medium">{user?.name}</div>
                          <div className="text-gray-500 truncate">{user?.email}</div>
                        </div>
                        <Link
                          to="/profile"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Your Profile
                        </Link>
                        <Link
                          to="/verification"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Apply for Verification
                        </Link>
                        <Link
                          to="/settings"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Settings
                        </Link>
                        <button
                          onClick={handleLogout}
                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Sign out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="text-gray-600 hover:text-primary transition-colors"
                >
                  Log in
                </Link>
                <Link 
                  to="/signup" 
                  className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
                >
                  Sign up
                </Link>
              </>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="flex md:hidden">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-600 hover:text-primary transition-colors"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={cn(
        'md:hidden fixed left-0 right-0 top-16 bg-white z-50 border-b border-gray-200 transform transition-transform duration-300 ease-in-out',
        mobileMenuOpen ? 'translate-y-0 shadow-lg' : '-translate-y-full'
      )}>
        <div className="px-4 pt-2 pb-4 space-y-1 sm:px-6">
          <form onSubmit={handleSearchSubmit} className="flex items-center mb-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 border border-gray-300 rounded-l-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
              placeholder="Search products..."
            />
            <button 
              type="submit" 
              className="bg-primary text-white p-2 rounded-r-lg hover:bg-primary/90"
            >
              <Search size={16} />
            </button>
          </form>
          
          {navLinks.map(link => (
            <Link
              key={link.name}
              to={link.path}
              className={cn(
                'block py-3 px-3 rounded-lg transition-colors',
                location.pathname === link.path 
                  ? 'bg-primary/10 text-primary font-medium' 
                  : 'text-gray-600 hover:bg-gray-50'
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              {link.name}
            </Link>
          ))}
          
          {isAuthenticated && (
            <Link 
              to="/messages" 
              className="flex items-center py-2 px-3 text-gray-600 hover:bg-gray-50 rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              <MessageSquare size={16} className="mr-2" />
              <span>Messages</span>
            </Link>
          )}
          
          {isAuthenticated ? (
            <>
              <Link 
                to="/create-listing" 
                className="block w-full bg-primary text-center text-white py-3 px-3 rounded-lg hover:bg-primary/90 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sell Item
              </Link>
              
              <div className="border-t border-gray-200 my-2 pt-2">
                <div className="flex items-center px-3 py-2">
                  {user?.profilePicture ? (
                    <img 
                      src={user.profilePicture} 
                      alt={user.name}
                      className="w-8 h-8 rounded-full object-cover mr-3"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                      <User size={16} className="text-gray-500" />
                    </div>
                  )}
                  <div>
                    <div className="font-medium">{user?.name}</div>
                    <div className="text-xs text-gray-500">{user?.email}</div>
                  </div>
                </div>
                
                <Link
                  to="/profile"
                  className="block py-2 px-3 text-gray-600 hover:bg-gray-50 rounded-lg"
                >
                  Your Profile
                </Link>
                
                <Link
                  to="/verification"
                  className="block py-2 px-3 text-gray-600 hover:bg-gray-50 rounded-lg"
                >
                  Apply for Verification
                </Link>
                
                <button
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="flex w-full items-center py-2 px-3 text-gray-600 hover:bg-gray-50 rounded-lg"
                >
                  <LogOut size={16} className="mr-2" />
                  <span>Sign out</span>
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col space-y-2 pt-2">
              <Link 
                to="/login" 
                className="block w-full text-center border border-gray-300 text-gray-700 py-3 px-3 rounded-lg hover:bg-gray-50 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Log in
              </Link>
              <Link 
                to="/signup" 
                className="block w-full bg-primary text-center text-white py-3 px-3 rounded-lg hover:bg-primary/90 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sign up
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
