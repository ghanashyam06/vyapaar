
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import { CreditCard, CheckCircle2 } from 'lucide-react';

interface PaymentGatewayProps {
  amount: number;
  productName: string;
  onSuccess: () => void;
  onCancel: () => void;
}

const PaymentGateway = ({ amount, productName, onSuccess, onCancel }: PaymentGatewayProps) => {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'cod'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  
  // Mock form data
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [upiId, setUpiId] = useState('');
  
  const handlePayment = () => {
    // Validate form based on payment method
    if (paymentMethod === 'card') {
      if (!cardNumber || !cardName || !expiryDate || !cvv) {
        toast.error('Please fill all the card details');
        return;
      }
      
      // Basic validation
      if (cardNumber.length < 16) {
        toast.error('Please enter a valid card number');
        return;
      }
      
      if (cvv.length < 3) {
        toast.error('Please enter a valid CVV');
        return;
      }
    } else if (paymentMethod === 'upi') {
      if (!upiId) {
        toast.error('Please enter your UPI ID');
        return;
      }
      
      // Basic UPI validation
      if (!upiId.includes('@')) {
        toast.error('Please enter a valid UPI ID');
        return;
      }
    }
    
    // Simulate payment processing
    setIsProcessing(true);
    
    setTimeout(() => {
      setIsProcessing(false);
      setIsComplete(true);
      
      setTimeout(() => {
        onSuccess();
      }, 2000);
    }, 2000);
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };
  
  if (isComplete) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6 flex flex-col items-center justify-center">
          <div className="rounded-full bg-green-100 p-3 mb-4">
            <CheckCircle2 className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-xl font-medium text-center mb-2">Payment Successful!</h2>
          <p className="text-gray-500 text-center mb-4">
            Your payment of {formatPrice(amount)} for {productName} has been processed successfully.
          </p>
          <Button onClick={onSuccess} className="w-full">
            Continue to Order Details
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Payment</CardTitle>
        <CardDescription>
          Complete your purchase for {productName}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="border rounded-lg p-3 bg-muted/50">
          <div className="flex justify-between mb-1">
            <span className="text-sm text-muted-foreground">Amount</span>
            <span className="font-medium">{formatPrice(amount)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Transaction fee</span>
            <span className="font-medium">₹0</span>
          </div>
          <div className="border-t my-2"></div>
          <div className="flex justify-between">
            <span className="font-medium">Total</span>
            <span className="font-bold text-premium-green">{formatPrice(amount)}</span>
          </div>
        </div>
        
        <div className="space-y-2">
          <Label>Select Payment Method</Label>
          <RadioGroup 
            value={paymentMethod} 
            onValueChange={(value) => setPaymentMethod(value as 'card' | 'upi' | 'cod')}
            className="flex flex-col space-y-2"
          >
            <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 cursor-pointer">
              <RadioGroupItem value="card" id="card" />
              <Label htmlFor="card" className="cursor-pointer flex-1">Credit/Debit Card</Label>
              <CreditCard className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 cursor-pointer">
              <RadioGroupItem value="upi" id="upi" />
              <Label htmlFor="upi" className="cursor-pointer flex-1">UPI</Label>
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/UPI-Logo-vector.svg/1280px-UPI-Logo-vector.svg.png" alt="UPI" className="h-6" />
            </div>
            <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 cursor-pointer">
              <RadioGroupItem value="cod" id="cod" />
              <Label htmlFor="cod" className="cursor-pointer flex-1">Cash on Delivery</Label>
              <span className="text-xs font-medium bg-premium-green/10 text-premium-green px-2 py-1 rounded">Available</span>
            </div>
          </RadioGroup>
        </div>
        
        {paymentMethod === 'card' && (
          <div className="space-y-3 pt-2">
            <div className="space-y-1">
              <Label htmlFor="cardNumber">Card Number</Label>
              <Input 
                id="cardNumber" 
                placeholder="1234 5678 9012 3456" 
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, ''))}
                maxLength={16}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="cardName">Cardholder Name</Label>
              <Input 
                id="cardName" 
                placeholder="John Doe" 
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label htmlFor="expiryDate">Expiry Date</Label>
                <Input 
                  id="expiryDate" 
                  placeholder="MM/YY" 
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  maxLength={5}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="cvv">CVV</Label>
                <Input 
                  id="cvv" 
                  placeholder="123" 
                  type="password" 
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                  maxLength={4}
                />
              </div>
            </div>
          </div>
        )}
        
        {paymentMethod === 'upi' && (
          <div className="space-y-3 pt-2">
            <div className="space-y-1">
              <Label htmlFor="upiId">UPI ID</Label>
              <Input 
                id="upiId" 
                placeholder="yourname@upi" 
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
              />
            </div>
          </div>
        )}
        
        {paymentMethod === 'cod' && (
          <div className="p-3 bg-green-50 text-green-800 rounded-lg border border-green-200 text-sm">
            <p>Cash on delivery is available for this product. You'll need to pay {formatPrice(amount)} when the product is delivered to you.</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        <Button 
          className="w-full" 
          onClick={handlePayment}
          disabled={isProcessing}
        >
          {isProcessing ? 'Processing...' : `Pay ${formatPrice(amount)}`}
        </Button>
        <Button variant="outline" className="w-full" onClick={onCancel}>
          Cancel
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PaymentGateway;
