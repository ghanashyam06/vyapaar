
import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'sonner';

// Define user type
export interface User {
  id: string;
  name: string;
  email: string;
  profilePicture?: string;
  phoneNumber?: string;
  authProvider?: 'email' | 'phone' | 'google';
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithPhoneOTP: (phoneNumber: string) => Promise<void>;
  verifyPhoneOTP: (phoneNumber: string, otp: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  registerWithGoogle: () => Promise<void>;
  registerWithPhoneOTP: (name: string, phoneNumber: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  sendOTP: (phoneNumber: string, isLogin?: boolean) => Promise<void>;
  resetVerificationState: () => void;
  verificationSent: boolean;
  phoneVerificationPending: boolean;
  pendingPhoneNumber: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [verificationSent, setVerificationSent] = useState(false);
  const [phoneVerificationPending, setPhoneVerificationPending] = useState(false);
  const [pendingPhoneNumber, setPendingPhoneNumber] = useState<string | null>(null);

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const resetVerificationState = () => {
    setVerificationSent(false);
    setPhoneVerificationPending(false);
    setPendingPhoneNumber(null);
  };

  const login = async (email: string, password: string) => {
    // In a real app, this would be an API call
    setIsLoading(true);
    
    try {
      // Mock API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock user - in a real app, this would come from your backend
      const mockUser: User = {
        id: '123',
        name: email.split('@')[0],
        email,
        profilePicture: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop',
        authProvider: 'email'
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
      toast.success('Logged in successfully');
    } catch (error) {
      console.error('Login failed:', error);
      throw new Error('Invalid email or password');
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setIsLoading(true);
    
    try {
      // Mock API delay - in a real app, this would redirect to Google OAuth
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock user after successful Google login
      const mockUser: User = {
        id: '456',
        name: 'Google User',
        email: 'google.user@gmail.com',
        profilePicture: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=1480&auto=format&fit=crop',
        authProvider: 'google'
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
      toast.success('Logged in with Google successfully');
    } catch (error) {
      console.error('Google login failed:', error);
      toast.error('Google login failed. Please try again.');
      throw new Error('Google login failed');
    } finally {
      setIsLoading(false);
    }
  };

  const sendOTP = async (phoneNumber: string, isLogin = false) => {
    setIsLoading(true);
    
    try {
      // Mock API delay - in a real app, this would send an OTP to the phone
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setVerificationSent(true);
      setPendingPhoneNumber(phoneNumber);
      setPhoneVerificationPending(true);
      
      toast.success(`OTP sent to ${phoneNumber}`);
    } catch (error) {
      console.error('Failed to send OTP:', error);
      toast.error('Failed to send OTP. Please try again.');
      throw new Error('Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithPhoneOTP = async (phoneNumber: string) => {
    try {
      await sendOTP(phoneNumber, true);
    } catch (error) {
      console.error('Phone login failed:', error);
      throw new Error('Phone login failed');
    }
  };

  const verifyPhoneOTP = async (phoneNumber: string, otp: string) => {
    setIsLoading(true);
    
    try {
      // Mock API delay - in a real app, this would verify the OTP
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo purposes, any 6-digit OTP is valid
      if (otp.length !== 6) {
        throw new Error('Invalid OTP');
      }
      
      // Mock user after successful phone verification
      const mockUser: User = {
        id: '789',
        name: `User ${phoneNumber.substring(phoneNumber.length - 4)}`,
        email: `user-${phoneNumber.replace(/\D/g, '')}@example.com`,
        phoneNumber,
        profilePicture: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=1374&auto=format&fit=crop',
        authProvider: 'phone'
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
      
      // Reset verification state
      resetVerificationState();
      toast.success('Phone verification successful');
    } catch (error) {
      console.error('OTP verification failed:', error);
      toast.error('Invalid OTP. Please try again.');
      throw new Error('OTP verification failed');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string) => {
    // In a real app, this would be an API call
    setIsLoading(true);
    
    try {
      // Mock API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock user creation - in a real app, this would be handled by your backend
      const mockUser: User = {
        id: '123',
        name,
        email,
        profilePicture: undefined,
        authProvider: 'email'
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
      toast.success('Registration successful');
    } catch (error) {
      console.error('Registration failed:', error);
      throw new Error('Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const registerWithGoogle = async () => {
    setIsLoading(true);
    
    try {
      // Mock API delay - in a real app, this would redirect to Google OAuth
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock user after successful Google registration
      const mockUser: User = {
        id: '456',
        name: 'Google User',
        email: 'google.user@gmail.com',
        profilePicture: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=1480&auto=format&fit=crop',
        authProvider: 'google'
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
      toast.success('Registered with Google successfully');
    } catch (error) {
      console.error('Google registration failed:', error);
      toast.error('Google registration failed. Please try again.');
      throw new Error('Google registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  const registerWithPhoneOTP = async (name: string, phoneNumber: string) => {
    try {
      await sendOTP(phoneNumber);
    } catch (error) {
      console.error('Phone registration failed:', error);
      throw new Error('Phone registration failed');
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    toast.success('Logged out successfully');
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        isLoading, 
        login,
        loginWithGoogle,
        loginWithPhoneOTP,
        verifyPhoneOTP,
        register, 
        registerWithGoogle,
        registerWithPhoneOTP,
        logout,
        isAuthenticated: !!user,
        sendOTP,
        resetVerificationState,
        verificationSent,
        phoneVerificationPending,
        pendingPhoneNumber
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
