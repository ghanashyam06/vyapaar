
import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import AuthLayout from '@/components/layouts/AuthLayout';
import AuthTabsContainer from '@/components/auth/AuthTabsContainer';
import EmailSignupForm from '@/components/auth/EmailSignupForm';
import PhoneSignupForm from '@/components/auth/PhoneSignupForm';
import GoogleSignupForm from '@/components/auth/GoogleSignupForm';
import PhoneVerification from '@/components/auth/PhoneVerification';
import { TabsContent } from '@/components/ui/tabs';

const Signup = () => {
  const [authTab, setAuthTab] = useState('email');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, registerWithGoogle, registerWithPhoneOTP, phoneVerificationPending } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get the redirect path from state or default to homepage
  const from = location.state?.from?.pathname || '/';
  
  const handleEmailSignup = async (name: string, email: string, password: string) => {
    setIsSubmitting(true);
    
    try {
      await register(name, email, password);
      navigate(from, { replace: true });
    } catch (error) {
      console.error('Registration error:', error);
      // Error is already handled in register
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignup = async () => {
    setIsSubmitting(true);
    
    try {
      await registerWithGoogle();
      navigate(from, { replace: true });
    } catch (error) {
      console.error('Google signup error:', error);
      // Error is already handled in registerWithGoogle
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePhoneSignup = async (phoneUserName: string, phoneNumber: string) => {
    setIsSubmitting(true);
    
    try {
      await registerWithPhoneOTP(phoneUserName, phoneNumber);
    } catch (error) {
      console.error('Phone signup error:', error);
      // Error is already handled in registerWithPhoneOTP
    } finally {
      setIsSubmitting(false);
    }
  };

  // If verification is pending, show the verification component
  if (phoneVerificationPending) {
    return (
      <AuthLayout 
        title="Verify Your Phone" 
        backLink={null}
      >
        <PhoneVerification onBack={() => setAuthTab('email')} />
      </AuthLayout>
    );
  }
  
  return (
    <AuthLayout 
      title="Create an Account" 
      subtitle="Join SNK Vyapar to buy and sell agricultural products"
    >
      <AuthTabsContainer activeTab={authTab} onTabChange={setAuthTab}>
        <TabsContent value="email" className="mt-6">
          <EmailSignupForm 
            onSubmit={handleEmailSignup}
            isSubmitting={isSubmitting}
            acceptTerms={acceptTerms}
            onTermsChange={setAcceptTerms}
          />
        </TabsContent>

        <TabsContent value="phone" className="mt-6">
          <PhoneSignupForm 
            onSubmit={handlePhoneSignup}
            isSubmitting={isSubmitting}
            acceptTerms={acceptTerms}
            onTermsChange={setAcceptTerms}
          />
        </TabsContent>

        <TabsContent value="google" className="mt-6">
          <GoogleSignupForm 
            onSubmit={handleGoogleSignup}
            isSubmitting={isSubmitting}
            acceptTerms={acceptTerms}
            onTermsChange={setAcceptTerms}
          />
        </TabsContent>
      </AuthTabsContainer>
      
      <div className="mt-8 pt-6 border-t border-gray-200 text-center">
        <p className="text-gray-600">
          Already have an account?{' '}
          <Link to="/login" className="text-primary font-medium hover:text-primary/80">
            Log in
          </Link>
        </p>
      </div>
    </AuthLayout>
  );
};

export default Signup;
