
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import FeaturedProducts from '@/components/marketplace/FeaturedProducts';
import { ArrowRight, ShoppingBag, BarChart2, Users, Shield } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section 
        className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.65), rgba(0, 0, 0, 0.4)), url(https://images.unsplash.com/photo-1523741543316-beb7fc7023d8?q=80&w=1974&auto=format&fit=crop)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Connecting Farmers <span className="text-premium-green">Directly</span> to Buyers
            </h1>
            <p className="text-lg md:text-xl mb-8 text-gray-100">
              SNK Vyapar helps farmers sell their produce directly, cutting out the middleman and increasing profits while providing fresh products to consumers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/marketplace">
                <Button size="lg" className="bg-premium-green hover:bg-premium-accent text-white font-medium px-8">
                  Explore Marketplace
                </Button>
              </Link>
              <Link to="/signup">
                <Button size="lg" variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white">
                  Join Our Community
                </Button>
              </Link>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose SNK Vyapar?</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our platform is designed to empower farmers and provide consumers with the freshest agricultural products.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gray-50 p-6 rounded-xl text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingBag className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Direct Sales</h3>
              <p className="text-gray-600">
                Farmers can sell directly to consumers without intermediaries, increasing their profits.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart2 className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Shelf Life Tracking</h3>
              <p className="text-gray-600">
                Our unique shelf life tracking system ensures you always know how fresh products are.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Community Support</h3>
              <p className="text-gray-600">
                Join a community of farmers and buyers committed to sustainable agriculture.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Secure Payments</h3>
              <p className="text-gray-600">
                Our platform offers secure payment options and escrow services for peace of mind.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Products Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Link 
              to="/marketplace" 
              className="text-primary hover:text-primary/80 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight size={16} />
            </Link>
          </div>
          
          <FeaturedProducts />
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Hear from farmers and buyers who have experienced the benefits of our marketplace.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-gradient-to-br from-white to-gray-50 p-6 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1520052203542-d3095f1b6cf0?q=80&w=1374&auto=format&fit=crop" 
                  alt="Farmer Testimonial" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-bold">Rajesh Kumar</h4>
                  <p className="text-sm text-gray-500">Vegetable Farmer, Maharashtra</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "SNK Vyapar has transformed my business. I now sell directly to customers and earn 40% more than before. The shelf life tracking feature helps me manage my inventory better."
              </p>
            </div>
            
            {/* Testimonial 2 */}
            <div className="bg-gradient-to-br from-white to-gray-50 p-6 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1528&auto=format&fit=crop" 
                  alt="Buyer Testimonial" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-bold">Priya Sharma</h4>
                  <p className="text-sm text-gray-500">Regular Buyer, Delhi</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "I love being able to buy directly from farmers. The produce is fresher, the prices are better, and I know exactly how long the items will stay fresh with the shelf life indicator."
              </p>
            </div>
            
            {/* Testimonial 3 */}
            <div className="bg-gradient-to-br from-white to-gray-50 p-6 rounded-xl border border-gray-100 shadow-sm">
              <div className="flex items-center mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1595475207225-428b62bda831?q=80&w=1460&auto=format&fit=crop" 
                  alt="Cooperative Testimonial" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-bold">Harvinder Singh</h4>
                  <p className="text-sm text-gray-500">Farmers' Cooperative, Punjab</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Our cooperative has expanded our customer base significantly since joining SNK Vyapar. The payment system is reliable and the platform is easy to use, even for farmers with limited tech experience."
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section 
        className="py-20 relative"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=1470&auto=format&fit=crop)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 leading-tight">
              Ready to Transform How You Buy and Sell Agricultural Products?
            </h2>
            <p className="text-lg mb-8">
              Join thousands of farmers and buyers already benefiting from our platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/signup">
                <Button size="lg" className="bg-premium-green hover:bg-premium-accent text-white font-medium px-8">
                  Create an Account
                </Button>
              </Link>
              <Link to="/about">
                <Button size="lg" variant="outline" className="bg-transparent hover:bg-white/10 text-white border-white">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-premium-dark text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">SNK Vyapar</h3>
              <p className="text-gray-300 mb-4">
                Connecting farmers and buyers directly for a more sustainable agricultural ecosystem.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-300 hover:text-white">Home</Link></li>
                <li><Link to="/marketplace" className="text-gray-300 hover:text-white">Marketplace</Link></li>
                <li><Link to="/about" className="text-gray-300 hover:text-white">About Us</Link></li>
                <li><Link to="/contact" className="text-gray-300 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">For Farmers</h4>
              <ul className="space-y-2">
                <li><Link to="/create-listing" className="text-gray-300 hover:text-white">Sell Your Products</Link></li>
                <li><a href="#testimonials" className="text-gray-300 hover:text-white">Success Stories</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Resources</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Contact Us</h4>
              <address className="text-gray-300 not-italic">
                <p>MLRIT College, Dundigal</p>
                <p>Hyderabad, Telangana, 500043</p>
                <p className="mt-2">contact@snkvyapar.com</p>
                <p>+91 9347599093</p>
              </address>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
