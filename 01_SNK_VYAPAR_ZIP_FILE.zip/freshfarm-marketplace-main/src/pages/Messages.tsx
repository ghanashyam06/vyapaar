
import { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { mockNotifications } from '@/data/mockNotifications';
import ContactList from '@/components/messages/ContactList';
import ChatArea from '@/components/messages/ChatArea';
import ProfileView from '@/components/messages/ProfileView';
import EmptyChat from '@/components/messages/EmptyChat';
import { Contact, Message } from '@/types/message';

// Enhanced mock contact data with more profile details
const mockContacts: Contact[] = [
  {
    id: 1,
    name: 'Organic Farmers Co.',
    position: 'Vegetable Supplier',
    location: 'Hyderabad, Telangana',
    rating: 4.8,
    lastMessage: 'Yes, the tomatoes are still available!',
    time: '10:30 AM',
    unread: 2,
    avatar: '/placeholder.svg',
    type: 'seller',
    phone: '+91 9876543210',
    email: 'organicfarmers@example.com'
  },
  {
    id: 2,
    name: 'SNK Vyapar Support',
    position: 'Technical Support',
    location: 'Dundigal, Hyderabad',
    rating: 5.0,
    lastMessage: 'How can we help you today?',
    time: 'Yesterday',
    unread: 0,
    avatar: '/placeholder.svg',
    type: 'support',
    phone: '+91 9347599093',
    email: 'support@snkvyapar.com'
  },
  {
    id: 3,
    name: 'Fresh Veggies Supplier',
    position: 'Wholesale Supplier',
    location: 'Secunderabad, Telangana',
    rating: 4.6,
    lastMessage: 'The delivery will be on Thursday.',
    time: 'Yesterday',
    unread: 1,
    avatar: '/placeholder.svg',
    type: 'seller',
    phone: '+91 9876543211',
    email: 'freshveggies@example.com'
  },
  {
    id: 4, 
    name: 'Grain Wholesalers',
    position: 'Grain Merchant',
    location: 'Warangal, Telangana',
    rating: 4.5,
    lastMessage: 'We can offer a discount on bulk orders.',
    time: '2 days ago',
    unread: 0,
    avatar: '/placeholder.svg',
    type: 'seller',
    phone: '+91 9876543212',
    email: 'grains@example.com'
  },
  {
    id: 5,
    name: 'Technical Support',
    position: 'Customer Service',
    location: 'Dundigal, Hyderabad',
    rating: 4.9,
    lastMessage: 'Your account has been verified successfully!',
    time: '3 days ago',
    unread: 0,
    avatar: '/placeholder.svg',
    type: 'support',
    phone: '+91 9347599093',
    email: 'tech@snkvyapar.com'
  }
];

// Mock conversation data for a selected contact
const mockConversations: Record<number, Message[]> = {
  1: [
    { id: 1, sender: 'them', content: 'Hello! I saw your interest in our organic tomatoes.', time: '10:15 AM' },
    { id: 2, sender: 'me', content: 'Yes, I\'m interested. Are they still available?', time: '10:20 AM' },
    { id: 3, sender: 'them', content: 'Yes, the tomatoes are still available!', time: '10:30 AM' },
    { id: 4, sender: 'them', content: 'We have 25kg in stock. How much would you like to order?', time: '10:31 AM' },
  ],
  2: [
    { id: 1, sender: 'them', content: 'Welcome to SNK Vyapar Support! How can we assist you today?', time: 'Yesterday 2:00 PM' },
    { id: 2, sender: 'me', content: 'I\'m having trouble with my payment method.', time: 'Yesterday 2:05 PM' },
    { id: 3, sender: 'them', content: 'I understand. Can you please provide more details about the issue you\'re experiencing?', time: 'Yesterday 2:10 PM' },
    { id: 4, sender: 'me', content: 'When I try to add my debit card, it shows an error.', time: 'Yesterday 2:15 PM' },
    { id: 5, sender: 'them', content: 'How can we help you today?', time: 'Yesterday 2:20 PM' },
  ],
  3: [
    { id: 1, sender: 'me', content: 'Hi, I\'d like to know when my order will be delivered.', time: 'Yesterday 10:00 AM' },
    { id: 2, sender: 'them', content: 'Hello! Your order #FV-2023 is being processed.', time: 'Yesterday 10:15 AM' },
    { id: 3, sender: 'them', content: 'The delivery will be on Thursday.', time: 'Yesterday 10:20 AM' },
  ],
  4: [
    { id: 1, sender: 'me', content: 'Do you offer any discounts for bulk orders?', time: '2 days ago' },
    { id: 2, sender: 'them', content: 'Yes, we certainly do!', time: '2 days ago' },
    { id: 3, sender: 'them', content: 'We can offer a discount on bulk orders.', time: '2 days ago' },
  ],
  5: [
    { id: 1, sender: 'them', content: 'We\'re reviewing your verification documents.', time: '3 days ago' },
    { id: 2, sender: 'them', content: 'Your account has been verified successfully!', time: '3 days ago' },
    { id: 3, sender: 'me', content: 'Great, thank you!', time: '3 days ago' },
  ]
};

const Messages = () => {
  const [contacts, setContacts] = useState(mockContacts);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const navigate = useNavigate();
  
  // Check if there are message notifications and add them to contacts if needed
  useEffect(() => {
    // Get all message type notifications from mockNotifications
    const messageNotifications = mockNotifications.filter(n => n.type === 'message');
    
    if (messageNotifications.length > 0) {
      // Check if the notification senders are already in our contacts
      const updatedContacts = [...contacts];
      let contactsChanged = false;
      
      messageNotifications.forEach(notification => {
        // Check if we already have this sender in our contacts
        const existingContactIndex = updatedContacts.findIndex(
          c => c.name === notification.sender
        );
        
        if (existingContactIndex === -1 && notification.sender) {
          // Add a new contact for this sender with all required fields
          updatedContacts.push({
            id: updatedContacts.length + 1,
            name: notification.sender,
            position: 'New Contact', // Default position
            location: 'Unknown Location', // Default location
            rating: 4.0, // Default rating
            lastMessage: notification.content,
            time: notification.time,
            unread: 1,
            avatar: notification.senderImg || '/placeholder.svg',
            type: 'seller',
            phone: '+91 9876543210', // Default phone
            email: 'contact@example.com' // Default email
          });
          contactsChanged = true;
        }
      });
      
      if (contactsChanged) {
        setContacts(updatedContacts);
      }
    }
  }, []);
  
  // Select a contact and load conversation
  const handleSelectContact = (contact: Contact) => {
    setSelectedContact(contact);
    setShowProfile(false);
    
    // Mark unread messages as read
    if (contact.unread > 0) {
      setContacts(contacts.map(c => 
        c.id === contact.id ? { ...c, unread: 0 } : c
      ));
    }
    
    // Load conversation
    setMessages(mockConversations[contact.id] || []);
  };
  
  // Go back to contact list
  const handleBackToContacts = () => {
    setSelectedContact(null);
    setShowProfile(false);
  };
  
  // Toggle profile view
  const toggleProfileView = () => {
    setShowProfile(!showProfile);
  };
  
  // Send a new message
  const handleSendMessage = (newMessage: string) => {
    if (!selectedContact) return;
    
    setIsSending(true);
    
    // Create new message
    const newMsg = {
      id: messages.length + 1,
      sender: 'me',
      content: newMessage,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    // Add message to conversation
    setMessages([...messages, newMsg]);
    
    // Update last message in contacts list
    setContacts(contacts.map(c => 
      c.id === selectedContact.id ? { 
        ...c, 
        lastMessage: newMessage,
        time: 'Just now'
      } : c
    ));
    
    // Simulate response after delay
    setTimeout(() => {
      setIsSending(false);
      // Play notification sound for feedback
      try {
        const audio = new Audio('/notification-sound.mp3');
        audio.play();
      } catch (error) {
        console.error('Audio play error:', error);
      }
      toast.success('Message sent successfully');
    }, 1000);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-6xl mx-auto px-4 pt-24 pb-12">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 h-[75vh]">
            {/* Contacts Panel */}
            <div className={`${(selectedContact && !showProfile) ? 'hidden md:block' : 'block'}`}>
              <ContactList 
                contacts={contacts} 
                selectedContact={selectedContact} 
                onSelectContact={handleSelectContact} 
              />
            </div>
            
            {/* User Profile View */}
            {selectedContact && showProfile && (
              <ProfileView 
                contact={selectedContact} 
                onBack={() => setShowProfile(false)} 
              />
            )}
            
            {/* Chat Area */}
            <div className={`col-span-2 flex flex-col ${
              !selectedContact ? 'hidden md:flex' : 
              (showProfile ? 'hidden md:hidden' : 'flex')
            }`}>
              {selectedContact ? (
                <ChatArea 
                  contact={selectedContact}
                  messages={messages}
                  isSending={isSending}
                  onSendMessage={handleSendMessage}
                  onBackToContacts={handleBackToContacts}
                  onToggleProfile={toggleProfileView}
                />
              ) : (
                <EmptyChat />
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Messages;
