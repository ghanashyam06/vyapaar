import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import { toast } from 'sonner';
import { NotificationHeader } from '@/components/notifications/NotificationHeader';
import { NotificationTabs } from '@/components/notifications/NotificationTabs';
import { MessageDialog } from '@/components/notifications/MessageDialog';
import { mockNotifications } from '@/data/mockNotifications';

const Notifications = () => {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [activeTab, setActiveTab] = useState('all');
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const navigate = useNavigate();
  
  const unreadCount = notifications.filter(n => !n.read).length;
  
  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };
  
  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    toast.success('All notifications marked as read');
  };
  
  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
    toast.success('Notification deleted');
  };
  
  const clearAllNotifications = () => {
    setNotifications([]);
    toast.success('All notifications cleared');
  };
  
  const handleNotificationClick = (notification) => {
    // Mark as read when clicked
    if (!notification.read) {
      markAsRead(notification.id);
    }
    
    // Open message dialog if it's a message type notification
    if (notification.type === 'message') {
      // Instead of showing dialog, redirect to messages page
      navigate('/messages');
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-3xl mx-auto px-4 pt-24 pb-12">
        <NotificationHeader 
          unreadCount={unreadCount} 
          onMarkAllAsRead={markAllAsRead} 
          onClearAll={clearAllNotifications} 
        />
        
        <NotificationTabs 
          notifications={notifications}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          unreadCount={unreadCount}
          onMarkAsRead={markAsRead}
          onDelete={deleteNotification}
          onNotificationClick={handleNotificationClick}
        />
      </main>
      
      {/* We'll keep the MessageDialog component for backward compatibility,
          but it won't be used for messages anymore */}
      <MessageDialog 
        open={messageDialogOpen} 
        onOpenChange={setMessageDialogOpen} 
        selectedMessage={selectedMessage} 
      />
    </div>
  );
};

export default Notifications;
