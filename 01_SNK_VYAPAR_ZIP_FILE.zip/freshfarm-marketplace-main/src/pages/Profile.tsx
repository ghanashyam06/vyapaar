
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import { User, Edit, ShoppingBag, Settings, Heart, CalendarDays, LogOut, ShieldCheck, Award } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Product } from '@/components/marketplace/ProductCard';

// Mock data for user's listings and saved items
const mockListings = [
  {
    id: '101',
    title: 'Farm-Fresh Tomatoes (5kg)',
    price: 250,
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?q=80&w=1470&auto=format&fit=crop',
    views: 45,
    status: 'active',
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    isVerified: true
  },
  {
    id: '102',
    title: 'Organic Wheat Flour (10kg)',
    price: 450,
    image: 'https://images.unsplash.com/photo-1586444248902-2f64eddc13df?q=80&w=1632&auto=format&fit=crop',
    views: 23,
    status: 'active',
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    isVerified: false
  }
];

const mockSavedItems = [
  {
    id: '201',
    title: 'Tractor for Rent (Daily/Weekly)',
    price: 1500,
    image: 'https://images.unsplash.com/photo-1633933088330-57a39575817f?q=80&w=1364&auto=format&fit=crop',
    sellerName: 'Krishna Machinery',
    isVerified: true
  },
  {
    id: '202',
    title: 'Drip Irrigation System (Complete Setup)',
    price: 12500,
    image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=1470&auto=format&fit=crop',
    sellerName: 'Modern Farming Solutions',
    isVerified: false
  }
];

const mockOrders = [
  {
    id: 'ORD-001',
    productName: 'Premium Saffron (10g)',
    price: 5200,
    image: 'https://images.unsplash.com/photo-1601508699916-84e9c84df44d?q=80&w=1364&auto=format&fit=crop',
    orderDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'Delivered',
    sellerName: 'Kashmir Spice Garden'
  },
  {
    id: 'ORD-002',
    productName: 'Organic Rice (25kg)',
    price: 1850,
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e8ac?q=80&w=1470&auto=format&fit=crop',
    orderDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'Shipped',
    sellerName: 'Punjab Organics'
  },
  {
    id: 'ORD-003',
    productName: 'Farm Tools Set',
    price: 3200,
    image: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?q=80&w=1365&auto=format&fit=crop',
    orderDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'Processing',
    sellerName: 'Agriculture Tools Ltd'
  }
];

const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("listings");
  const [activeSidebar, setActiveSidebar] = useState("dashboard");
  const [savedItems, setSavedItems] = useState(mockSavedItems);
  const [userOrders, setUserOrders] = useState(mockOrders);
  const [userListings, setUserListings] = useState(mockListings);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/login', { replace: true });
    }
  }, [user, navigate]);
  
  if (!user) {
    return null; // Don't render anything while redirecting
  }
  
  const handleLogout = () => {
    logout();
    toast.success('You have been logged out successfully');
    navigate('/');
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };
  
  const handleRemoveSavedItem = (id: string) => {
    const updatedItems = savedItems.filter(item => item.id !== id);
    setSavedItems(updatedItems);
    toast.success('Item removed from saved list');
  };
  
  const handleDeleteListing = (id: string) => {
    const updatedListings = userListings.filter(listing => listing.id !== id);
    setUserListings(updatedListings);
    toast.success('Listing deleted successfully');
  };
  
  const renderTabContent = () => {
    switch (activeSidebar) {
      case "dashboard":
        return (
          <Tabs defaultValue="listings" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="listings">My Listings</TabsTrigger>
              <TabsTrigger value="saved">Saved Items</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="listings" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Your Active Listings</h3>
                <Link to="/create-listing">
                  <Button>
                    <Edit className="mr-2 h-4 w-4" /> Create New Listing
                  </Button>
                </Link>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userListings.map(listing => (
                  <Card key={listing.id} className="overflow-hidden">
                    <div className="flex h-32">
                      <div className="w-1/3">
                        <img 
                          src={listing.image} 
                          alt={listing.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="w-2/3 p-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium text-sm line-clamp-1">{listing.title}</h4>
                          <span className="text-premium-green font-medium">{formatPrice(listing.price)}</span>
                        </div>
                        <div className="mt-2 flex items-center text-xs text-gray-500">
                          <CalendarDays className="h-3 w-3 mr-1" />
                          <span>Posted {new Date(listing.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div className="mt-1 text-xs text-gray-500 flex items-center">
                          {listing.views} views
                          {listing.isVerified && (
                            <Badge variant="outline" className="ml-2 h-5 text-[10px] bg-green-50 text-green-700 border-green-200">
                              <ShieldCheck className="h-3 w-3 mr-1" />
                              Verified
                            </Badge>
                          )}
                        </div>
                        <div className="mt-2 flex gap-2">
                          <Button size="sm" variant="outline" className="text-xs h-7 px-2" onClick={() => navigate(`/product/${listing.id}`)}>View</Button>
                          <Button size="sm" variant="outline" className="text-xs h-7 px-2">Edit</Button>
                          <Button size="sm" variant="outline" className="text-xs h-7 px-2 text-destructive" onClick={() => handleDeleteListing(listing.id)}>Delete</Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="saved" className="space-y-4">
              <h3 className="text-lg font-medium">Saved Items</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedItems.map(item => (
                  <Card key={item.id} className="overflow-hidden">
                    <div className="flex h-32">
                      <div className="w-1/3">
                        <img 
                          src={item.image} 
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="w-2/3 p-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium text-sm line-clamp-1">{item.title}</h4>
                          <span className="text-premium-green font-medium">{formatPrice(item.price)}</span>
                        </div>
                        <div className="mt-1 text-xs text-gray-500 flex items-center">
                          Seller: {item.sellerName}
                          {item.isVerified && (
                            <Badge variant="outline" className="ml-2 h-5 text-[10px] bg-green-50 text-green-700 border-green-200">
                              <ShieldCheck className="h-3 w-3 mr-1" />
                              Verified
                            </Badge>
                          )}
                        </div>
                        <div className="mt-2 flex gap-2">
                          <Button 
                            size="sm" 
                            className="text-xs h-7 px-2"
                            onClick={() => navigate(`/product/${item.id}`)}
                          >
                            View Details
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-xs h-7 px-2"
                            onClick={() => handleRemoveSavedItem(item.id)}
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="analytics" className="space-y-4">
              <h3 className="text-lg font-medium">Account Analytics</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-premium-green">45</div>
                      <div className="text-sm text-gray-500 mt-1">Total Views</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-premium-green">12</div>
                      <div className="text-sm text-gray-500 mt-1">Inquiries</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-premium-green">3</div>
                      <div className="text-sm text-gray-500 mt-1">Completed Sales</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        );
      
      case "orders":
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">My Orders</h2>
            <div className="grid grid-cols-1 gap-4">
              {userOrders.map(order => (
                <Card key={order.id} className="overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="w-full md:w-1/5 h-24 md:h-auto">
                      <img 
                        src={order.image} 
                        alt={order.productName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="w-full md:w-4/5 p-4">
                      <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                        <div>
                          <h4 className="font-medium">{order.productName}</h4>
                          <div className="text-sm text-gray-500">Seller: {order.sellerName}</div>
                          <div className="text-sm text-gray-500">
                            Order Date: {new Date(order.orderDate).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex flex-col items-start md:items-end">
                          <span className="font-semibold text-premium-green">{formatPrice(order.price)}</span>
                          <Badge 
                            className={`mt-1 ${
                              order.status === 'Delivered' 
                                ? 'bg-green-100 text-green-800' 
                                : order.status === 'Shipped' 
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {order.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Button size="sm" variant="outline" className="text-xs">Track Order</Button>
                        <Button size="sm" variant="outline" className="text-xs">View Details</Button>
                        {order.status === 'Delivered' && (
                          <Button size="sm" variant="outline" className="text-xs">Write Review</Button>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );
      
      case "saved":
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Saved Items</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {savedItems.map(item => (
                <Card key={item.id} className="overflow-hidden">
                  <div className="flex h-32">
                    <div className="w-1/3">
                      <img 
                        src={item.image} 
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="w-2/3 p-4">
                      <div className="flex justify-between">
                        <h4 className="font-medium text-sm line-clamp-1">{item.title}</h4>
                        <span className="text-premium-green font-medium">{formatPrice(item.price)}</span>
                      </div>
                      <div className="mt-1 text-xs text-gray-500">
                        Seller: {item.sellerName}
                      </div>
                      <div className="mt-2 flex gap-2">
                        <Button 
                          size="sm" 
                          className="text-xs h-7 px-2"
                          onClick={() => navigate(`/product/${item.id}`)}
                        >
                          View Details
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="text-xs h-7 px-2"
                          onClick={() => handleRemoveSavedItem(item.id)}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );
      
      case "settings":
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Account Settings</h2>
            <Card>
              <CardContent className="pt-6">
                <form className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Full Name</label>
                    <input 
                      type="text" 
                      defaultValue={user.name}
                      className="w-full border rounded-md px-3 py-2"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email</label>
                    <input 
                      type="email" 
                      defaultValue={user.email}
                      className="w-full border rounded-md px-3 py-2"
                      disabled
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Phone Number</label>
                    <input 
                      type="tel" 
                      defaultValue="+91 9876543210"
                      className="w-full border rounded-md px-3 py-2"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Location</label>
                    <input 
                      type="text" 
                      defaultValue="Mumbai, Maharashtra"
                      className="w-full border rounded-md px-3 py-2"
                    />
                  </div>
                  <div className="pt-2">
                    <Button>Save Changes</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Password & Security</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Current Password</label>
                    <input 
                      type="password" 
                      className="w-full border rounded-md px-3 py-2"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">New Password</label>
                    <input 
                      type="password" 
                      className="w-full border rounded-md px-3 py-2"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Confirm New Password</label>
                    <input 
                      type="password" 
                      className="w-full border rounded-md px-3 py-2"
                    />
                  </div>
                  <div className="pt-2">
                    <Button>Update Password</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Verification Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <ShieldCheck size={32} className="text-premium-green" />
                  <div>
                    <h3 className="font-medium">Farmer Verification</h3>
                    <p className="text-sm text-gray-500">Get verified to increase trust and sales</p>
                  </div>
                  <Button className="ml-auto" variant="outline">Apply for Verification</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="page-container pt-24">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Profile Sidebar */}
          <div className="w-full md:w-1/3 lg:w-1/4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center mb-6">
                  {user.profilePicture ? (
                    <img 
                      src={user.profilePicture} 
                      alt={user.name}
                      className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md mb-4"
                    />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
                      <User size={40} />
                    </div>
                  )}
                  <h2 className="text-xl font-bold">{user.name}</h2>
                  <p className="text-gray-500">{user.email}</p>
                  
                  <div className="mt-4 w-full">
                    <Button 
                      variant={activeSidebar === "dashboard" ? "default" : "outline"} 
                      className="w-full justify-start mt-2"
                      onClick={() => setActiveSidebar("dashboard")}
                    >
                      <User className="mr-2 h-4 w-4" /> Dashboard
                    </Button>
                    <Button 
                      variant={activeSidebar === "orders" ? "default" : "outline"} 
                      className="w-full justify-start mt-2"
                      onClick={() => setActiveSidebar("orders")}
                    >
                      <ShoppingBag className="mr-2 h-4 w-4" /> My Orders
                    </Button>
                    <Button 
                      variant={activeSidebar === "saved" ? "default" : "outline"} 
                      className="w-full justify-start mt-2"
                      onClick={() => setActiveSidebar("saved")}
                    >
                      <Heart className="mr-2 h-4 w-4" /> Saved Items
                    </Button>
                    <Button 
                      variant={activeSidebar === "settings" ? "default" : "outline"} 
                      className="w-full justify-start mt-2"
                      onClick={() => setActiveSidebar("settings")}
                    >
                      <Settings className="mr-2 h-4 w-4" /> Settings
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start mt-2 text-destructive hover:text-destructive"
                      onClick={handleLogout}
                    >
                      <LogOut className="mr-2 h-4 w-4" /> Logout
                    </Button>
                  </div>
                </div>
                
                <div className="border-t border-gray-200 pt-4">
                  <h3 className="font-medium text-gray-900 mb-2">Account Info</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Member since</span>
                      <span className="text-gray-900">Jan 2023</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Listings</span>
                      <span className="text-gray-900">{userListings.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Saved items</span>
                      <span className="text-gray-900">{savedItems.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Orders</span>
                      <span className="text-gray-900">{userOrders.length}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main Content */}
          <div className="w-full md:w-2/3 lg:w-3/4">
            <Card>
              <CardHeader>
                <CardTitle>{activeSidebar === "dashboard" ? "Dashboard" : 
                           activeSidebar === "orders" ? "My Orders" :
                           activeSidebar === "saved" ? "Saved Items" : "Account Settings"}</CardTitle>
              </CardHeader>
              <CardContent>
                {renderTabContent()}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-200 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-500 text-sm">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Profile;
