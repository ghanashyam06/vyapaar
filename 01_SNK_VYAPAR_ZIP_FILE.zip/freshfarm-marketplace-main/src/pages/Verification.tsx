
import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import { Shield, Upload, CheckCircle, X, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

const formSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters." }),
  phoneNumber: z.string().min(10, { message: "Please enter a valid phone number." }),
  address: z.string().min(5, { message: "Address must be at least 5 characters." }),
  city: z.string().min(2, { message: "City name is required." }),
  state: z.string().min(2, { message: "State name is required." }),
  reason: z.string().min(20, { message: "Please provide a detailed reason (at least 20 characters)." }),
});

const Verification = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: user?.name || "",
      phoneNumber: "",
      address: "",
      city: "",
      state: "",
      reason: "",
    },
  });
  
  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.includes('video/')) {
        if (file.size > 100 * 1024 * 1024) { // 100MB limit
          toast.error("Video file is too large", {
            description: "Please upload a video smaller than 100MB"
          });
          return;
        }
        
        setVideoFile(file);
        const url = URL.createObjectURL(file);
        setVideoPreview(url);
      } else {
        toast.error("Invalid file type", {
          description: "Please upload a video file"
        });
      }
    }
  };
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (!videoFile && step === 2) {
      toast.error("Video is required", {
        description: "Please record or upload a video explaining why you want verification"
      });
      return;
    }
    
    if (step === 1) {
      setStep(2);
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success("Verification request submitted", {
        description: "We'll review your application and get back to you soon"
      });
      navigate('/profile');
    }, 2000);
  };
  
  const handleCancel = () => {
    if (step === 2) {
      setStep(1);
    } else {
      navigate('/profile');
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 pt-24 pb-12">
        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Verification Application</h1>
          <p className="text-gray-600 max-w-xl mx-auto">
            Get verified to increase trust with buyers and unlock premium features. Complete both steps below to submit your application.
          </p>
        </div>
        
        <div className="flex justify-between mb-8 max-w-md mx-auto">
          <div className="flex flex-col items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-500'}`}>
              1
            </div>
            <span className="text-sm mt-2">Basic Details</span>
          </div>
          <div className="flex-1 flex items-center justify-center">
            <div className={`h-1 w-full ${step >= 2 ? 'bg-primary' : 'bg-gray-200'}`}></div>
          </div>
          <div className="flex flex-col items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-500'}`}>
              2
            </div>
            <span className="text-sm mt-2">Video Submission</span>
          </div>
        </div>
        
        <Card className="w-full border">
          <CardHeader>
            <CardTitle>{step === 1 ? "Basic Information" : "Video Submission"}</CardTitle>
            <CardDescription>
              {step === 1 
                ? "Please provide your personal details for verification" 
                : "Upload a short video explaining why you want to be verified"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === 1 ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="+91 9876543210" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Your address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input placeholder="Your city" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>State</FormLabel>
                          <FormControl>
                            <Input placeholder="Your state" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="reason"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reason for Verification</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Explain why you want to be verified on our platform..."
                            className="min-h-[120px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          This helps us understand your business better.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-4 flex justify-end space-x-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleCancel}
                    >
                      Cancel
                    </Button>
                    <Button type="submit">Continue to Video</Button>
                  </div>
                </form>
              </Form>
            ) : (
              <div className="space-y-6">
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <Info className="h-5 w-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Video Guidelines</h4>
                      <ul className="mt-1 text-sm text-gray-600 list-disc pl-5 space-y-1">
                        <li>Keep your video between 30-60 seconds</li>
                        <li>Clearly state your name and location</li>
                        <li>Explain why you want to be verified</li>
                        <li>Mention how you plan to use our platform</li>
                        <li>Make sure you're in a well-lit environment</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center">
                  {videoPreview ? (
                    <div className="w-full">
                      <div className="relative">
                        <video 
                          ref={videoRef}
                          src={videoPreview} 
                          controls
                          className="w-full rounded-lg max-h-[300px]"
                        ></video>
                        <button
                          type="button"
                          onClick={() => {
                            setVideoFile(null);
                            setVideoPreview(null);
                          }}
                          className="absolute top-2 right-2 bg-gray-800/70 text-white p-1 rounded-full"
                        >
                          <X size={16} />
                        </button>
                      </div>
                      <p className="text-sm text-gray-500 mt-2 text-center">
                        {videoFile?.name} - {(videoFile?.size / (1024 * 1024)).toFixed(2)} MB
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload className="h-12 w-12 text-gray-400 mb-2" />
                      <h3 className="text-lg font-medium text-gray-900">Upload your video</h3>
                      <p className="text-sm text-gray-500 text-center mb-4">
                        Drag and drop your video or click to browse
                      </p>
                      <input
                        type="file"
                        id="video-upload"
                        accept="video/*"
                        onChange={handleVideoChange}
                        className="hidden"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById('video-upload')?.click()}
                      >
                        Select Video
                      </Button>
                    </>
                  )}
                </div>
              </div>
            )}
          </CardContent>
          {step === 2 && (
            <CardFooter className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleCancel}
              >
                Back to Details
              </Button>
              <Button 
                onClick={() => onSubmit(form.getValues())} 
                disabled={!videoFile || isSubmitting}
              >
                {isSubmitting ? "Submitting..." : "Submit Application"}
              </Button>
            </CardFooter>
          )}
        </Card>
        
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <CheckCircle className="h-5 w-5 text-blue-500" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-800">Verification Benefits</h3>
              <div className="mt-2 text-sm text-blue-700">
                <ul className="list-disc pl-5 space-y-1">
                  <li>Verified badge increases buyer trust</li>
                  <li>Higher ranking in search results</li>
                  <li>Access to premium selling tools</li>
                  <li>Eligibility for featured listings</li>
                  <li>Priority customer support</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Verification;
