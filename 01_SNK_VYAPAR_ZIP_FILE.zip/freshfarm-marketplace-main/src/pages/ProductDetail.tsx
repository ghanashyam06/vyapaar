import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  MapPin, 
  Calendar, 
  MessageCircle, 
  Phone, 
  Share2, 
  Heart, 
  ArrowLeft,
  AlertCircle,
  User,
  Check,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  ShieldCheck,
  Award,
  Scale,
  MapPin as LocationPin,
  Info,
  Truck,
  Package,
  Star
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import ShelfLifeIndicator from '@/components/marketplace/ShelfLifeIndicator';
import { Product } from '@/components/marketplace/ProductCard';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import PaymentGateway from '@/components/payments/PaymentGateway';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/context/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Updated product categories - removed pesticides and fertilizers
const productCategories = [
  'Fruits', 
  'Vegetables', 
  'Grains', 
  'Dairy Products', 
  'Poultry', 
  'Meat', 
  'Seeds', 
  'Farm Equipment',
  'Irrigation Systems',
  'Organic Products',
  'Spices',
  'Processed Foods',
  'Flowers',
  'Honey & Bee Products'
];

// Updated mock data with better images
const mockProducts: Product[] = [
  {
    id: '1',
    title: 'Premium Alphonso Mangoes (1 Dozen)',
    price: 1200,
    negotiable: true,
    location: 'Ratnagiri, Maharashtra',
    category: 'Fruits',
    shelfLife: 7,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Premium quality Alphonso mangoes directly from our farm. These mangoes are harvested at the perfect ripeness and are incredibly sweet and aromatic. Each mango weighs approximately 250-300 grams. The box contains a dozen mangoes, carefully packed to prevent any damage during shipping. These mangoes are grown using organic practices without any harmful pesticides or chemicals. Order now to enjoy the king of fruits at its best!',
    images: [
      'https://images.unsplash.com/photo-1591073113125-e46713c829ed?q=80&w=1112&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1553279768-865429fa0078?q=80&w=1374&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1601493700721-df5f63720175?q=80&w=1470&auto=format&fit=crop'
    ],
    sellerName: 'Raj Farms',
    sellerAvatar: 'https://images.unsplash.com/photo-1582201943021-e8e5cb6163bd?q=80&w=1470&auto=format&fit=crop',
    verifiedFarmer: true,
    weight: '3-4 kg (12 pcs)',
    organicCertified: true,
    origin: 'Ratnagiri, Maharashtra',
    nutritionalInfo: 'Rich in Vitamin A, C and fiber',
    harvestDate: '2 days ago',
    stockQuantity: 50,
    phone: '+91 9876543210'
  },
  {
    id: '2',
    title: 'Organic Basmati Rice (10kg)',
    price: 850,
    negotiable: false,
    location: 'Basmati Belt, Punjab',
    category: 'Grains',
    shelfLife: 180,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    description: "Finest quality basmati rice, organically grown without pesticides. Long grain, aromatic rice that's perfect for biryani and pulao. Directly sourced from our farms in Punjab.",
    images: [
      'https://images.unsplash.com/photo-1594204114385-1e0402c05e33?q=80&w=1470&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1613758235402-745466bb7efe?q=80&w=1464&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1586444248836-f8e41a5eecc7?q=80&w=1470&auto=format&fit=crop'
    ],
    sellerName: 'Punjab Organics',
    sellerAvatar: 'https://images.unsplash.com/photo-1604467715878-83e57e8bc129?q=80&w=1480&auto=format&fit=crop',
    verifiedFarmer: true,
    weight: '10 kg',
    organicCertified: true,
    origin: 'Punjab',
    nutritionalInfo: 'High in carbohydrates, low in fat',
    harvestDate: '1 month ago',
    stockQuantity: 100,
    phone: '+91 9876543211'
  }
];

const ProductDetail = () => {
  
  const [isSaved, setIsSaved] = useState(false);
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [daysRemaining, setDaysRemaining] = useState(0);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [offer, setOffer] = useState('');
  const [showOfferForm, setShowOfferForm] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    // Check if user is authenticated
    if (!user) {
      toast.error("Please login to view product details");
      navigate("/login", { state: { from: `/product/${id}` } });
      return;
    }
    
    // Check if this product is saved
    const savedProducts = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    setIsSaved(savedProducts.includes(id));
    
    // Simulate fetching product from an API
    setIsLoading(true);
    setTimeout(() => {
      const foundProduct = mockProducts.find(p => p.id === id);
      if (foundProduct) {
        setProduct(foundProduct);
        
        // Calculate days remaining
        const creationDate = new Date(foundProduct.createdAt);
        const today = new Date();
        const timeDiff = today.getTime() - creationDate.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
        setDaysRemaining(Math.max(0, foundProduct.shelfLife - daysDiff));
      } else {
        toast.error('Product not found');
      }
      setIsLoading(false);
    }, 500);
  }, [id, user, navigate]);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };
  
  const handlePrevImage = () => {
    setActiveImageIndex((prevIndex) => (prevIndex > 0 ? prevIndex - 1 : product!.images.length - 1));
  };
  
  const handleNextImage = () => {
    setActiveImageIndex((prevIndex) => (prevIndex < product!.images.length - 1 ? prevIndex + 1 : 0));
  };
  
  const handleThumbnailClick = (index: number) => {
    setActiveImageIndex(index);
  };
  
  const handleContact = () => {
    if (product?.phone) {
      // For mobile devices, open the phone app
      window.location.href = `tel:${product.phone}`;
      toast.success("Redirecting to call app");
    } else {
      // Show contact info if no phone number available
      setShowContactInfo(true);
      toast.info("Contact information displayed");
    }
  };
  
  const handlePaymentSuccess = () => {
    setShowPaymentModal(false);
    toast.success('Order placed successfully!');
  };
  
  const handleBuyNow = () => {
    setShowPaymentModal(true);
  };
  
  const handleSendOffer = () => {
    if (!offer) {
      toast.error('Please enter your offer');
      return;
    }
    
    // Simulate sending offer
    toast.success(`Offer of ${offer} sent to seller`);
    setShowOfferForm(false);
  };
  
  const handleShare = () => {
    try {
      // Create share data object
      const shareData = {
        title: product!.title,
        text: `Check out this product: ${product!.title}`,
        url: window.location.href,
      };
      
      // Try using the Web Share API if available
      if (navigator.share) {
        navigator.share(shareData)
          .then(() => toast.success('Shared successfully'))
          .catch((error) => {
            console.error('Error sharing', error);
            // Fallback to clipboard if share fails
            navigator.clipboard.writeText(window.location.href)
              .then(() => toast.success('Link copied to clipboard'))
              .catch(() => toast.error('Failed to copy link'));
          });
      } else {
        // Fallback for browsers that don't support the Web Share API
        navigator.clipboard.writeText(window.location.href)
          .then(() => toast.success('Link copied to clipboard'))
          .catch(() => toast.error('Failed to copy link'));
      }
    } catch (error) {
      console.error('Error sharing', error);
      toast.error('Failed to share product');
    }
  };
  
  const handleSave = () => {
    // Get saved products from local storage
    const savedProducts = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    
    if (isSaved) {
      // Remove product from saved list
      const updatedSavedProducts = savedProducts.filter((savedId: string) => savedId !== id);
      localStorage.setItem('savedProducts', JSON.stringify(updatedSavedProducts));
      setIsSaved(false);
      toast.success('Product removed from saved items');
    } else {
      // Add product to saved list
      savedProducts.push(id);
      localStorage.setItem('savedProducts', JSON.stringify(savedProducts));
      setIsSaved(true);
      toast.success('Product saved successfully');
    }
  };
  
  if (isLoading) {
    
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading product details...</p>
        </div>
      </div>
    );
  }
  
  if (!product) {
    
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertCircle size={48} className="text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
          <p className="text-gray-600">Sorry, we couldn't find the product you were looking for.</p>
          <Link to="/marketplace" className="text-primary hover:underline">
            Back to Marketplace
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="page-container pt-24">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link
            to="/marketplace"
            className="inline-flex items-center gap-1.5 text-gray-600 hover:text-primary transition-colors"
          >
            <ArrowLeft size={18} />
            <span>Back to Marketplace</span>
          </Link>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Column - Images */}
          <div className="w-full lg:w-3/5">
            {/* Main Image */}
            <div className="relative bg-white rounded-xl overflow-hidden aspect-video mb-4 shadow-sm">
              <img
                src={product?.images[activeImageIndex]}
                alt={product?.title}
                className="w-full h-full object-contain"
              />
              
              {product?.images.length > 1 && (
                <>
                  <button
                    onClick={handlePrevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 rounded-full p-2 shadow-md transition-colors"
                    aria-label="Previous image"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 rounded-full p-2 shadow-md transition-colors"
                    aria-label="Next image"
                  >
                    <ChevronRight size={20} />
                  </button>
                </>
              )}
            </div>
            
            {/* Thumbnails */}
            {product?.images.length > 1 && (
              <div className="flex gap-2 mb-8 overflow-x-auto pb-2 hide-scrollbar">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => handleThumbnailClick(index)}
                    className={cn(
                      "w-20 h-20 border rounded-lg overflow-hidden flex-shrink-0 transition-all",
                      activeImageIndex === index 
                        ? "border-primary ring-2 ring-primary/30" 
                        : "border-gray-200 hover:border-gray-300"
                    )}
                  >
                    <img
                      src={image}
                      alt={`${product.title} - image ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
            
            {/* Product Information */}
            <div className="space-y-6">
              {/* Product Description */}
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-semibold mb-4">Description</h2>
                <p className="text-gray-700 whitespace-pre-line leading-relaxed">
                  {product?.description}
                </p>
              </div>
              
              {/* Product Details */}
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-semibold mb-4">Product Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product?.weight && (
                    <div className="flex items-start gap-3">
                      <Scale className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">Weight</h3>
                        <p className="text-sm text-gray-600">{product.weight}</p>
                      </div>
                    </div>
                  )}
                  
                  {product?.origin && (
                    <div className="flex items-start gap-3">
                      <LocationPin className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">Origin</h3>
                        <p className="text-sm text-gray-600">{product.origin}</p>
                      </div>
                    </div>
                  )}
                  
                  {product?.harvestDate && (
                    <div className="flex items-start gap-3">
                      <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">Harvest Date</h3>
                        <p className="text-sm text-gray-600">{product.harvestDate}</p>
                      </div>
                    </div>
                  )}
                  
                  {product?.stockQuantity !== undefined && (
                    <div className="flex items-start gap-3">
                      <Package className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">Stock Available</h3>
                        <p className="text-sm text-gray-600">{product.stockQuantity} units</p>
                      </div>
                    </div>
                  )}
                  
                  {product?.nutritionalInfo && (
                    <div className="flex items-start gap-3 col-span-2">
                      <Info className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">Nutritional Information</h3>
                        <p className="text-sm text-gray-600">{product.nutritionalInfo}</p>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="mt-6 flex flex-wrap gap-2">
                  {product?.organicCertified && (
                    <Badge variant="outline" className="flex items-center gap-1 bg-green-50 text-green-700 border-green-200">
                      <Award size={14} />
                      Organic Certified
                    </Badge>
                  )}
                  
                  {product?.verifiedFarmer && (
                    <Badge variant="outline" className="flex items-center gap-1 bg-blue-50 text-blue-700 border-blue-200">
                      <ShieldCheck size={14} />
                      Verified Farmer
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Column - Product Details */}
          <div className="w-full lg:w-2/5 space-y-6">
            {/* Product Info Card */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex justify-between items-start">
                <h1 className="text-2xl font-bold mb-2">{product?.title}</h1>
                {product?.verifiedFarmer && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <ShieldCheck size={22} className="text-premium-green" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Verified by SNK Vyapar</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
              
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl font-bold text-premium-green">
                  {formatPrice(product?.price || 0)}
                </span>
                {product?.negotiable && (
                  <span className="bg-primary/10 text-primary text-xs font-medium px-2 py-1 rounded">
                    Negotiable
                  </span>
                )}
              </div>
              
              <div className="flex flex-col gap-3 mb-6">
                <div className="flex items-center text-gray-600">
                  <Calendar size={18} className="mr-2 flex-shrink-0" />
                  <span>
                    Listed on {product ? new Date(product.createdAt).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    }) : ''}
                  </span>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <MapPin size={18} className="mr-2 flex-shrink-0" />
                  <span>{product?.location}</span>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <div className="mr-2 px-2 py-1 bg-gray-100 rounded text-xs font-medium">
                    {product?.category}
                  </div>
                </div>
                
                <div className="mt-1">
                  <div className="text-sm text-gray-500 mb-1">Freshness</div>
                  <ShelfLifeIndicator
                    initialDays={product?.shelfLife || 0}
                    currentDays={daysRemaining}
                    showProgressBar={true}
                    size="md"
                  />
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex flex-col gap-3">
                <button
                  onClick={handleBuyNow}
                  className="w-full bg-premium-green hover:bg-premium-accent text-white py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <CreditCard size={18} />
                  <span>Buy Now</span>
                </button>
                
                <button
                  onClick={handleContact}
                  className="w-full bg-white border border-gray-200 hover:border-gray-300 text-gray-700 py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Phone size={18} />
                  <span>Contact Seller</span>
                </button>
                
                {product?.negotiable && (
                  <button
                    onClick={() => setShowOfferForm(!showOfferForm)}
                    className="w-full bg-white border border-primary text-primary hover:bg-primary/5 py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle size={18} />
                    <span>Make an Offer</span>
                  </button>
                )}
                
                {showOfferForm ? (
                  <div className="flex flex-col gap-2">
                    <input
                      type="number"
                      placeholder="Enter your offer"
                      className="border rounded-md px-4 py-2"
                      value={offer}
                      onChange={(e) => setOffer(e.target.value)}
                    />
                    <button
                      onClick={handleSendOffer}
                      className="bg-primary text-white py-2 rounded-md hover:bg-primary/90 transition-colors"
                    >
                      Send Offer
                    </button>
                  </div>
                ) : null}
                
                <div className="flex justify-between items-center">
                  <button
                    onClick={handleShare}
                    className="bg-white border border-gray-200 hover:border-gray-300 text-gray-700 py-2 rounded-lg transition-colors w-1/2 flex items-center justify-center gap-2"
                  >
                    <Share2 size={18} />
                    <span>Share</span>
                  </button>
                  
                  <button 
                    className={`border py-2 rounded-lg transition-colors w-1/2 flex items-center justify-center gap-2 ${isSaved ? 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100' : 'bg-white border-gray-200 hover:border-gray-300 text-gray-700'}`}
                    onClick={handleSave}
                  >
                    <Heart size={18} className={isSaved ? 'fill-red-500 text-red-500' : ''} />
                    <span>{isSaved ? 'Saved' : 'Save'}</span>
                  </button>
                </div>
              </div>
            </div>
            
            {/* Seller Info Card */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                Seller Information
                {product?.verifiedFarmer && (
                  <Badge variant="outline" className="flex items-center gap-1 bg-premium-green/10 border-premium-green/30 text-premium-green">
                    <ShieldCheck size={12} className="mr-0.5" />
                    Verified
                  </Badge>
                )}
              </h2>
              <div className="flex items-center gap-3 mb-4">
                {product?.sellerAvatar ? (
                  <img 
                    src={product.sellerAvatar} 
                    alt={product.sellerName}
                    className="w-12 h-12 rounded-full object-cover border border-gray-200"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                    <User size={24} />
                  </div>
                )}
                <div>
                  <h3 className="font-medium">{product?.sellerName}</h3>
                  <div className="text-sm text-gray-500">Member since Jan 2022</div>
                  <div className="flex items-center mt-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star 
                        key={star} 
                        size={14} 
                        className={star <= 4 ? "text-yellow-400 fill-yellow-400" : "text-gray-300"} 
                      />
                    ))}
                    <span className="text-xs text-gray-500 ml-1">(24 reviews)</span>
                  </div>
                </div>
              </div>
              
              {showContactInfo ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Phone size={16} className="flex-shrink-0" />
                    <span>{product?.phone || '+91 9876543210'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <MessageCircle size={16} className="flex-shrink-0" />
                    <span>Available on WhatsApp</span>
                  </div>
                </div>
              ) : (
                <button
                  onClick={handleContact}
                  className="w-full bg-white border border-gray-200 hover:border-gray-300 text-gray-700 py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Phone size={18} />
                  <span>Show Contact Info</span>
                </button>
              )}
            </div>
            
            {/* Safety Tips */}
            <div className="bg-yellow-50 border border-yellow-100 rounded-xl p-5">
              <h3 className="text-sm font-medium text-yellow-800 mb-2">Safety Tips</h3>
              <ul className="text-xs text-yellow-700 space-y-1">
                <li className="flex items-start gap-1.5">
                  <span className="text-yellow-500 mt-0.5">•</span>
                  Meet in a safe, public location
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-yellow-500 mt-0.5">•</span>
                  Verify the product before purchasing
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-yellow-500 mt-0.5">•</span>
                  Avoid paying before receiving the product
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogTitle>Complete Your Purchase</DialogTitle>
          <DialogDescription>
            Enter your payment details to purchase {product?.title}
          </DialogDescription>
          <PaymentGateway 
            amount={product?.price || 0}
            productName={product?.title || ''}
            onSuccess={handlePaymentSuccess}
            onCancel={() => setShowPaymentModal(false)}
          />
        </DialogContent>
      </Dialog>
      
      <footer className="bg-white border-t border-gray-200 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-500 text-sm">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ProductDetail;
