import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, Plus, Award, ShieldCheck } from 'lucide-react';
import Navbar from '@/components/Navbar';
import SearchFilters, { SearchParams } from '@/components/marketplace/SearchFilters';
import ProductCard, { Product } from '@/components/marketplace/ProductCard';
import ShelfLifeIndicator from '@/components/marketplace/ShelfLifeIndicator';
import FeaturedProducts from '@/components/marketplace/FeaturedProducts';
import { Button } from '@/components/ui/button';

// This is mock data with updated images - in a real app, you'd fetch this from an API
const mockProducts: Product[] = [
  {
    id: '1',
    title: 'Premium Alphonso Mangoes (1 Dozen)',
    price: 1200,
    negotiable: true,
    location: 'Ratnagiri, Maharashtra',
    category: 'Fruits',
    shelfLife: 7,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Premium quality Alphonso mangoes directly from our farm. Sweet and perfect ripeness.',
    images: ['https://images.unsplash.com/photo-1591073113125-e46713c829ed?q=80&w=1112&auto=format&fit=crop'],
    sellerName: 'Raj Farms',
    verifiedFarmer: true,
    weight: '3-4 kg (12 pcs)',
    organicCertified: true,
    origin: 'Ratnagiri, Maharashtra',
    nutritionalInfo: 'Rich in Vitamin A, C and fiber',
    harvestDate: '2 days ago',
    stockQuantity: 50,
    phone: '+91 9876543210'
  },
  {
    id: '2',
    title: 'Organic Basmati Rice (10kg)',
    price: 850,
    negotiable: false,
    location: 'Basmati Belt, Punjab',
    category: 'Grains',
    shelfLife: 180,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Finest quality basmati rice, organically grown without pesticides.',
    images: ['https://images.unsplash.com/photo-1594204114385-1e0402c05e33?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Punjab Organics',
    verifiedFarmer: true,
    weight: '10 kg',
    organicCertified: true,
    origin: 'Punjab',
    nutritionalInfo: 'High in carbohydrates, low in fat',
    harvestDate: '1 month ago',
    stockQuantity: 100,
    phone: '+91 9876543211'
  },
  {
    id: '3',
    title: 'Farm Fresh Tomatoes',
    price: 60,
    negotiable: true,
    location: 'Nashik, Maharashtra',
    category: 'Vegetables',
    shelfLife: 5,
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Fresh red tomatoes picked this morning. Perfect for salads and cooking.',
    images: ['https://images.unsplash.com/photo-1592924357520-e34c487e3c6c?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Green Valley',
    weight: '1 kg',
    origin: 'Nashik, Maharashtra',
    harvestDate: 'Today',
    stockQuantity: 150,
    phone: '+91 9876543212'
  },
  {
    id: '4',
    title: 'Tractor for Rent (John Deere)',
    price: 1500,
    negotiable: true,
    location: 'Panipat, Haryana',
    category: 'Equipment',
    shelfLife: 365,
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'John Deere tractor available for rent on daily, weekly or monthly basis. Well maintained.',
    images: ['https://images.unsplash.com/photo-1592805144716-feeccccef5ac?q=80&w=1374&auto=format&fit=crop'],
    sellerName: 'Haryana Agro Services',
    verifiedFarmer: true,
    phone: '+91 9876543213'
  },
  {
    id: '5',
    title: 'Organic Honey (1kg)',
    price: 650,
    negotiable: false,
    location: 'Coorg, Karnataka',
    category: 'Dairy & Produce',
    shelfLife: 365,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Pure organic honey collected from our bee farms in Coorg. No additives or sugar.',
    images: ['https://images.unsplash.com/photo-1587049352851-8d4e89133924?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Honey Heaven',
    organicCertified: true,
    weight: '1 kg',
    origin: 'Coorg, Karnataka',
    nutritionalInfo: 'Natural antioxidants and antibacterial properties',
    stockQuantity: 75,
    phone: '+91 9876543214'
  },
  {
    id: '6',
    title: 'Himalayan Organic Potatoes (5kg)',
    price: 210,
    negotiable: false,
    location: 'Shimla, Himachal Pradesh',
    category: 'Vegetables',
    shelfLife: 14,
    createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Fresh organic potatoes from the hills of Himachal. No pesticides used.',
    images: ['https://images.unsplash.com/photo-1518977676601-b53f82aba655?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Himalayan Organics',
    organicCertified: true,
    weight: '5 kg',
    origin: 'Shimla, Himachal Pradesh',
    harvestDate: '3 days ago',
    stockQuantity: 125,
    phone: '+91 9876543215'
  },
  {
    id: '7',
    title: 'Farm Fresh Eggs (30 pcs)',
    price: 240,
    negotiable: true,
    location: 'Pune, Maharashtra',
    category: 'Dairy & Produce',
    shelfLife: 21,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Free-range chicken eggs. Hens are fed organic feed without antibiotics.',
    images: ['https://images.unsplash.com/photo-1598965675045-45c5e72c7d05?q=80&w=1436&auto=format&fit=crop'],
    sellerName: 'Happy Hens Farm',
    verifiedFarmer: true,
    weight: '30 pcs',
    nutritionalInfo: 'High in protein and vitamin D',
    stockQuantity: 200,
    phone: '+91 9876543216'
  },
  {
    id: '8',
    title: 'Sprinkler Irrigation System',
    price: 6500,
    negotiable: true,
    location: 'Ahmedabad, Gujarat',
    category: 'Equipment',
    shelfLife: 1825,
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Complete sprinkler irrigation system for 1 acre land. Includes pipes, sprinklers, and connectors.',
    images: ['https://images.unsplash.com/photo-1621464475557-14b4bba6d5c5?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Irrigation Solutions',
    verifiedFarmer: true,
    phone: '+91 9876543217'
  },
  {
    id: '9',
    title: 'Premium Saffron (10g)',
    price: 5200,
    negotiable: false,
    location: 'Pampore, Kashmir',
    category: 'Spices',
    shelfLife: 730,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'High-quality Kashmiri saffron, carefully hand-picked and 100% pure.',
    images: ['https://images.unsplash.com/photo-1601508699916-84e9c84df44d?q=80&w=1364&auto=format&fit=crop'],
    sellerName: 'Kashmir Spice Garden',
    verifiedFarmer: true,
    weight: '10g',
    origin: 'Kashmir Valley',
    organicCertified: true,
    nutritionalInfo: 'Rich in antioxidants and has medicinal properties',
    harvestDate: '2 weeks ago',
    stockQuantity: 25,
    phone: '+91 9876543218'
  },
  {
    id: '10',
    title: 'Organic Turmeric Powder (500g)',
    price: 220,
    negotiable: false,
    location: 'Erode, Tamil Nadu',
    category: 'Spices',
    shelfLife: 365,
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'High-curcumin organic turmeric powder, grown without chemicals or pesticides.',
    images: ['https://images.unsplash.com/photo-1615485500704-8e990f9900f7?q=80&w=1374&auto=format&fit=crop'],
    sellerName: 'Tamil Organic Farms',
    organicCertified: true,
    weight: '500g',
    origin: 'Erode, Tamil Nadu',
    nutritionalInfo: 'High in curcumin, anti-inflammatory properties',
    stockQuantity: 150,
    phone: '+91 9876543219'
  },
  {
    id: '11',
    title: 'Organic Wheat Seeds (50kg)',
    price: 3500,
    negotiable: true,
    location: 'Ludhiana, Punjab',
    category: 'Seeds',
    shelfLife: 365,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'High-yield wheat seeds for the upcoming season. Certified organic quality.',
    images: ['https://images.unsplash.com/photo-1567721913486-6585f069b332?q=80&w=1528&auto=format&fit=crop'],
    sellerName: 'Punjab Seed Bank',
    verifiedFarmer: true,
    weight: '50kg',
    origin: 'Punjab Agricultural University',
    stockQuantity: 50,
    phone: '+91 9876543220'
  },
  {
    id: '12',
    title: 'Fresh Coconuts (10 pcs)',
    price: 350,
    negotiable: false,
    location: 'Kochi, Kerala',
    category: 'Fruits',
    shelfLife: 30,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    description: 'Young tender coconuts, perfect for drinking and eating the soft kernel.',
    images: ['https://images.unsplash.com/photo-1544681280-d23a28c28c80?q=80&w=1470&auto=format&fit=crop'],
    sellerName: 'Kerala Coconut Farms',
    verifiedFarmer: true,
    weight: '~15kg (10 pcs)',
    origin: 'Kerala',
    nutritionalInfo: 'Rich in electrolytes and minerals',
    harvestDate: 'This week',
    stockQuantity: 80,
    phone: '+91 9876543221'
  }
];

// Updated product categories - removed pesticides and fertilizers
const productCategories = [
  'All Categories',
  'Fruits',
  'Vegetables',
  'Grains',
  'Spices',
  'Dairy & Produce',
  'Seeds',
  'Organic Products',
  'Equipment',
  'Irrigation',
  'Tools',
  'Processing',
  'Storage Solutions'
];

const Marketplace = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All Categories');
  const [showVerifiedOnly, setShowVerifiedOnly] = useState(false);
  const [showOrganicOnly, setShowOrganicOnly] = useState(false);
  
  useEffect(() => {
    // Simulate API call with setTimeout
    const timer = setTimeout(() => {
      setProducts(mockProducts);
      setFilteredProducts(mockProducts);
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleSearch = (params: SearchParams) => {
    // Filter products based on search parameters
    let filtered = [...products];
    
    // Filter by query (search in title and description)
    if (params.query) {
      const query = params.query.toLowerCase();
      filtered = filtered.filter(product => 
        product.title.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query)
      );
    }
    
    // Filter by category
    if (params.category && params.category !== 'All Categories') {
      filtered = filtered.filter(product => product.category === params.category);
    }
    
    // Filter by price range
    if (params.priceRange[0] !== null) {
      filtered = filtered.filter(product => product.price >= (params.priceRange[0] || 0));
    }
    if (params.priceRange[1] !== null) {
      filtered = filtered.filter(product => product.price <= (params.priceRange[1] || Infinity));
    }
    
    // Filter by location
    if (params.location) {
      const location = params.location.toLowerCase();
      filtered = filtered.filter(product => 
        product.location.toLowerCase().includes(location)
      );
    }
    
    // Filter by shelf life
    if (params.shelfLife !== null) {
      // Calculate remaining shelf life for each product
      filtered = filtered.filter(product => {
        const creationDate = new Date(product.createdAt);
        const currentDate = new Date();
        const daysPassed = Math.floor((currentDate.getTime() - creationDate.getTime()) / (1000 * 60 * 60 * 24));
        const remainingDays = Math.max(0, product.shelfLife - daysPassed);
        return remainingDays >= params.shelfLife!;
      });
    }
    
    // Sort products
    switch (params.sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'freshest':
        filtered.sort((a, b) => {
          // Calculate remaining shelf life percentage for comparison
          const getShelfLifePercentage = (product: Product) => {
            const creationDate = new Date(product.createdAt);
            const currentDate = new Date();
            const daysPassed = Math.floor((currentDate.getTime() - creationDate.getTime()) / (1000 * 60 * 60 * 24));
            return (product.shelfLife - daysPassed) / product.shelfLife;
          };
          return getShelfLifePercentage(b) - getShelfLifePercentage(a);
        });
        break;
    }
    
    setFilteredProducts(filtered);
  };
  
  const handleCategoryFilter = (category: string) => {
    setActiveCategory(category);
    
    let filtered = [...products];
    if (category !== 'All Categories') {
      filtered = filtered.filter(product => product.category === category);
    }
    
    // Apply verified and organic filters
    if (showVerifiedOnly) {
      filtered = filtered.filter(product => product.verifiedFarmer);
    }
    
    if (showOrganicOnly) {
      filtered = filtered.filter(product => product.organicCertified);
    }
    
    setFilteredProducts(filtered);
  };
  
  const toggleVerifiedFilter = () => {
    const newValue = !showVerifiedOnly;
    setShowVerifiedOnly(newValue);
    
    let filtered = [...products];
    if (activeCategory !== 'All Categories') {
      filtered = filtered.filter(product => product.category === activeCategory);
    }
    
    if (newValue) {
      filtered = filtered.filter(product => product.verifiedFarmer);
    }
    
    if (showOrganicOnly) {
      filtered = filtered.filter(product => product.organicCertified);
    }
    
    setFilteredProducts(filtered);
  };
  
  const toggleOrganicFilter = () => {
    const newValue = !showOrganicOnly;
    setShowOrganicOnly(newValue);
    
    let filtered = [...products];
    if (activeCategory !== 'All Categories') {
      filtered = filtered.filter(product => product.category === activeCategory);
    }
    
    if (showVerifiedOnly) {
      filtered = filtered.filter(product => product.verifiedFarmer);
    }
    
    if (newValue) {
      filtered = filtered.filter(product => product.organicCertified);
    }
    
    setFilteredProducts(filtered);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="page-container pt-24">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-bold tracking-tight mb-4 text-gradient-dark">Farm Fresh Marketplace</h1>
          <p className="text-lg text-gray-600">
            Connect directly with farmers and sellers. Buy and sell farm-fresh produce, 
            agricultural tools, and equipment.
          </p>
          
          <div className="flex flex-wrap justify-center gap-2 mt-6">
            <Button 
              variant={showVerifiedOnly ? "default" : "outline"} 
              size="sm"
              onClick={toggleVerifiedFilter}
              className="flex items-center gap-1"
            >
              <ShieldCheck size={16} />
              <span>Verified Farmers</span>
            </Button>
            
            <Button 
              variant={showOrganicOnly ? "default" : "outline"} 
              size="sm"
              onClick={toggleOrganicFilter}
              className="flex items-center gap-1"
            >
              <Award size={16} />
              <span>Organic Only</span>
            </Button>
          </div>
        </div>
        
        {/* Featured Products Section */}
        <section className="mb-12">
          <FeaturedProducts 
            title="Featured Products" 
            subtitle="Discover the freshest and most popular agricultural products from farmers across India." 
          />
        </section>
        
        {/* Categories */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Browse by Category</h2>
          <div className="flex overflow-x-auto gap-3 pb-2 hide-scrollbar">
            {productCategories.map((category) => (
              <Button
                key={category}
                variant={activeCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => handleCategoryFilter(category)}
                className="whitespace-nowrap"
              >
                {category}
              </Button>
            ))}
          </div>
        </section>
        
        {/* Main Marketplace Section */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">All Products</h2>
            <Link 
              to="/create-listing" 
              className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            >
              <Plus size={18} />
              <span>Sell Item</span>
            </Link>
          </div>
          
          <SearchFilters onSearch={handleSearch} className="mb-8" />
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="marketplace-card animate-pulse">
                  <div className="aspect-[4/3] bg-gray-200"></div>
                  <div className="p-4">
                    <div className="h-5 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-500 mb-6">Try adjusting your search or filter criteria</p>
              <button
                onClick={() => {
                  setFilteredProducts(products);
                  setActiveCategory('All Categories');
                  setShowVerifiedOnly(false);
                  setShowOrganicOnly(false);
                }}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </section>
      </main>
      
      <footer className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-500 text-sm">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Marketplace;
