
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Navbar from '@/components/Navbar';
import ProductForm from '@/components/marketplace/ProductForm';

const CreateListing = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="page-container pt-24 max-w-4xl mx-auto">
        <div className="mb-6">
          <Link
            to="/marketplace"
            className="inline-flex items-center gap-1.5 text-gray-600 hover:text-primary transition-colors"
          >
            <ArrowLeft size={18} />
            <span>Back to Marketplace</span>
          </Link>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sm:p-8">
          <h1 className="text-2xl sm:text-3xl font-bold mb-2">Create a Listing</h1>
          <p className="text-gray-600 mb-8">
            Fill in the details below to create your product listing. Fields marked with * are required.
          </p>
          
          <ProductForm />
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-200 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-500 text-sm">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CreateListing;
