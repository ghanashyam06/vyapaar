
import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import AuthLayout from '@/components/layouts/AuthLayout';
import AuthTabsContainer from '@/components/auth/AuthTabsContainer';
import EmailLoginForm from '@/components/auth/EmailLoginForm';
import PhoneLoginForm from '@/components/auth/PhoneLoginForm';
import GoogleLoginForm from '@/components/auth/GoogleLoginForm';
import PhoneVerification from '@/components/auth/PhoneVerification';
import { TabsContent } from '@/components/ui/tabs';
import { toast } from 'sonner';

const Login = () => {
  const [authTab, setAuthTab] = useState(() => {
    // Try to get the last used tab from localStorage
    const savedTab = localStorage.getItem('authTab');
    return savedTab || 'email';
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { login, loginWithGoogle, loginWithPhoneOTP, phoneVerificationPending } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get the redirect path from state or default to homepage
  const from = location.state?.from?.pathname || '/';
  
  // Save the current tab to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('authTab', authTab);
  }, [authTab]);

  const handleEmailLogin = async (email: string, password: string) => {
    setIsSubmitting(true);
    
    try {
      await login(email, password);
      navigate(from, { replace: true });
    } catch (error) {
      console.error('Login error:', error);
      // Error is already handled in login
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsSubmitting(true);
    
    try {
      await loginWithGoogle();
      navigate(from, { replace: true });
    } catch (error) {
      console.error('Google login error:', error);
      toast.error('Google login failed. Please check your internet connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePhoneLogin = async (phoneNumber: string) => {
    setIsSubmitting(true);
    
    try {
      await loginWithPhoneOTP(phoneNumber);
    } catch (error) {
      console.error('Phone login error:', error);
      // Error is already handled in loginWithPhoneOTP
    } finally {
      setIsSubmitting(false);
    }
  };

  // If verification is pending, show the verification component
  if (phoneVerificationPending) {
    return (
      <AuthLayout 
        title="Verify Your Phone" 
        backLink={null}
      >
        <PhoneVerification onBack={() => setAuthTab('email')} />
      </AuthLayout>
    );
  }
  
  return (
    <AuthLayout 
      title="Welcome Back" 
      subtitle="Log in to access your SNK Vyapar account"
    >
      <AuthTabsContainer activeTab={authTab} onTabChange={setAuthTab}>
        <TabsContent value="email" className="mt-6">
          <EmailLoginForm
            onSubmit={handleEmailLogin}
            isSubmitting={isSubmitting}
          />
        </TabsContent>

        <TabsContent value="phone" className="mt-6">
          <PhoneLoginForm
            onSubmit={handlePhoneLogin}
            isSubmitting={isSubmitting}
          />
        </TabsContent>

        <TabsContent value="google" className="mt-6">
          <GoogleLoginForm
            onSubmit={handleGoogleLogin}
            isSubmitting={isSubmitting}
          />
        </TabsContent>
      </AuthTabsContainer>
      
      <div className="mt-8 pt-6 border-t border-gray-200 text-center">
        <p className="text-gray-600">
          Don't have an account?{' '}
          <Link to="/signup" className="text-primary font-medium hover:text-primary/80">
            Sign up
          </Link>
        </p>
      </div>
    </AuthLayout>
  );
};

export default Login;
