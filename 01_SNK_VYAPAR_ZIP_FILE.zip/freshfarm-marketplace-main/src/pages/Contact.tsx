
import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Message Sent",
        description: "Thank you for reaching out! We'll get back to you shortly.",
      });
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <section className="mb-16">
            <div className="text-center mb-10">
              <h1 className="text-4xl font-bold tracking-tight mb-4">Contact Us</h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Have questions or need support? Our team is here to help you with any inquiries about our marketplace.
              </p>
            </div>
            
            <div className="relative overflow-hidden rounded-xl mb-10">
              <img 
                src="https://images.unsplash.com/photo-1557234195-bd9f290f0e4d?q=80&w=1470&auto=format&fit=crop" 
                alt="Farm field" 
                className="w-full h-[300px] object-cover"
              />
              <div className="absolute inset-0 bg-premium-green/30"></div>
            </div>
          </section>
          
          {/* Contact Info Cards */}
          <section className="mb-16">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg text-center shadow-sm">
                <div className="bg-premium-green/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-6 w-6 text-premium-green" />
                </div>
                <h3 className="text-lg font-medium mb-2">Our Location</h3>
                <p className="text-gray-600">
                  MLRIT College, Dundigal<br />
                  Hyderabad, Telangana
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg text-center shadow-sm">
                <div className="bg-premium-green/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-6 w-6 text-premium-green" />
                </div>
                <h3 className="text-lg font-medium mb-2">Phone</h3>
                <p className="text-gray-600">
                  Customer Support: +91 9347599093<br />
                  Seller Support: +91 9347599093
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg text-center shadow-sm">
                <div className="bg-premium-green/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6 text-premium-green" />
                </div>
                <h3 className="text-lg font-medium mb-2">Email</h3>
                <p className="text-gray-600">
                  info@snkvyapar.com<br />
                  support@snkvyapar.com
                </p>
              </div>
            </div>
          </section>
          
          {/* Contact Form */}
          <section>
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium mb-6 text-center">Send us a Message</h3>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Your Name</label>
                  <input 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full border rounded-md px-3 py-2" 
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email Address</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full border rounded-md px-3 py-2" 
                    required
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Subject</label>
                  <input 
                    type="text" 
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full border rounded-md px-3 py-2" 
                    required
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium">Message</label>
                  <textarea 
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full border rounded-md px-3 py-2 h-32" 
                    required
                  ></textarea>
                </div>
                <div className="md:col-span-2 flex justify-center">
                  <Button 
                    type="submit"
                    className="bg-premium-green hover:bg-premium-accent text-white px-8"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></span>
                        Sending...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Send size={16} />
                        Send Message
                      </span>
                    )}
                  </Button>
                </div>
              </form>
            </div>
          </section>
          
          {/* Project Credit */}
          <section className="mt-8 text-center text-gray-600">
            <p>Special thanks to Amrita Madam for her invaluable support in creating this project.</p>
          </section>
        </div>
      </main>
      
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-400">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Contact;
