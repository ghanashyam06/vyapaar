import React from 'react';
import Navbar from '@/components/Navbar';
import { 
  ShieldCheck, 
  Truck, 
  Leaf, 
  Users, 
  HandshakeIcon, 
  Facebook,
  Twitter,
  Instagram,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const About = () => {
  // Scroll to top when component mounts
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="pt-24">
        {/* Hero Section */}
        <section className="relative h-[500px] overflow-hidden">
          <div className="absolute inset-0 w-full h-full">
            <img 
              src="https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?q=80&w=1470&auto=format&fit=crop" 
              alt="Farmers working in agriculture" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-premium-dark/40"></div>
          </div>
          
          <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
            <div className="max-w-2xl">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Connecting Farmers Directly to Markets</h1>
              <p className="text-xl text-white/90 mb-8">
                SNK Vyapar is revolutionizing agricultural commerce by eliminating middlemen and creating a sustainable marketplace.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button asChild size="lg" className="bg-premium-green hover:bg-premium-accent text-white">
                  <Link to="/marketplace">
                    Explore Marketplace
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white border-white/30">
                  <Link to="/signup">
                    Join as Farmer
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Mission Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
              <p className="text-lg text-gray-600">
                We're dedicated to empowering farmers by providing them with direct access to markets, 
                fair prices for their produce, and the tools they need to thrive in the digital economy.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="bg-premium-green/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Truck className="h-8 w-8 text-premium-green" />
                </div>
                <h3 className="text-xl font-medium mb-2">Direct Market Access</h3>
                <p className="text-gray-600">
                  We connect farmers directly with buyers, eliminating middlemen and ensuring better prices.
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="bg-premium-green/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Leaf className="h-8 w-8 text-premium-green" />
                </div>
                <h3 className="text-xl font-medium mb-2">Sustainable Farming</h3>
                <p className="text-gray-600">
                  We promote and highlight sustainable and organic farming practices that are better for the environment.
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <div className="bg-premium-green/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ShieldCheck className="h-8 w-8 text-premium-green" />
                </div>
                <h3 className="text-xl font-medium mb-2">Verified Sellers</h3>
                <p className="text-gray-600">
                  Our verification system ensures that buyers can trust the authenticity and quality of products.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* How It Works */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
              <p className="text-lg text-gray-600">
                A simple process that connects farmers directly with buyers, 
                making agricultural commerce more efficient and fair.
              </p>
            </div>
            
            <div className="relative">
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-premium-green/20 hidden md:block"></div>
              
              <div className="space-y-12 relative">
                <div className="flex flex-col md:flex-row items-center">
                  <div className="md:w-1/2 md:pr-12 mb-6 md:mb-0 md:text-right">
                    <h3 className="text-xl font-medium mb-2">Register as a Farmer or Buyer</h3>
                    <p className="text-gray-600">
                      Create your account, verify your details, and start using our platform to sell or buy agricultural products.
                    </p>
                  </div>
                  <div className="md:w-12 flex justify-center">
                    <div className="w-10 h-10 rounded-full bg-premium-green flex items-center justify-center text-white relative z-10">
                      1
                    </div>
                  </div>
                  <div className="md:w-1/2 md:pl-12 md:text-left"></div>
                </div>
                
                <div className="flex flex-col md:flex-row items-center">
                  <div className="md:w-1/2 md:pr-12 mb-6 md:mb-0 md:text-right order-1 md:order-1"></div>
                  <div className="md:w-12 flex justify-center order-2">
                    <div className="w-10 h-10 rounded-full bg-premium-green flex items-center justify-center text-white relative z-10">
                      2
                    </div>
                  </div>
                  <div className="md:w-1/2 md:pl-12 md:text-left order-3">
                    <h3 className="text-xl font-medium mb-2">List Your Products or Browse Listings</h3>
                    <p className="text-gray-600">
                      Farmers can create detailed listings for their products. Buyers can search and filter products based on their needs.
                    </p>
                  </div>
                </div>
                
                <div className="flex flex-col md:flex-row items-center">
                  <div className="md:w-1/2 md:pr-12 mb-6 md:mb-0 md:text-right">
                    <h3 className="text-xl font-medium mb-2">Connect and Negotiate</h3>
                    <p className="text-gray-600">
                      Communicate directly with sellers/buyers, negotiate prices, and arrange logistics.
                    </p>
                  </div>
                  <div className="md:w-12 flex justify-center">
                    <div className="w-10 h-10 rounded-full bg-premium-green flex items-center justify-center text-white relative z-10">
                      3
                    </div>
                  </div>
                  <div className="md:w-1/2 md:pl-12 md:text-left"></div>
                </div>
                
                <div className="flex flex-col md:flex-row items-center">
                  <div className="md:w-1/2 md:pr-12 mb-6 md:mb-0 md:text-right order-1 md:order-1"></div>
                  <div className="md:w-12 flex justify-center order-2">
                    <div className="w-10 h-10 rounded-full bg-premium-green flex items-center justify-center text-white relative z-10">
                      4
                    </div>
                  </div>
                  <div className="md:w-1/2 md:pl-12 md:text-left order-3">
                    <h3 className="text-xl font-medium mb-2">Secure Payment and Delivery</h3>
                    <p className="text-gray-600">
                      Complete transactions securely through our platform. Rate and review your experience to build a trusted community.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Farmer Success Stories */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Farmer Success Stories</h2>
              <p className="text-lg text-gray-600">
                Hear from the farmers who have transformed their businesses through our platform.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <img
                    src="https://images.unsplash.com/photo-1594750853530-c85f7eeeb976?q=80&w=1374&auto=format&fit=crop"
                    alt="Farmer portrait"
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-medium">Rajesh Kumar</h3>
                    <p className="text-sm text-gray-500">Tomato Farmer, Nashik</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "Before joining SNK Vyapar, I was forced to sell my tomatoes at whatever price the middlemen offered. Now I can set my own prices and connect directly with restaurants and retailers. My income has increased by 40%."
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <img
                    src="https://images.unsplash.com/photo-1583753013941-4842e32574be?q=80&w=1374&auto=format&fit=crop"
                    alt="Farmer portrait"
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-medium">Anita Patel</h3>
                    <p className="text-sm text-gray-500">Mango Grower, Ratnagiri</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "The verification badge on my profile has helped me establish trust with urban customers who are willing to pay premium prices for authentic Alphonso mangoes. The platform has expanded my reach beyond local markets."
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <img
                    src="https://images.unsplash.com/photo-1615302365403-05433ba09c84?q=80&w=1374&auto=format&fit=crop"
                    alt="Farmer portrait"
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-medium">Gurpreet Singh</h3>
                    <p className="text-sm text-gray-500">Rice Farmer, Punjab</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "The analytics dashboard helps me understand market demand and plan my harvests better. I've been able to reduce waste and optimize my pricing strategy based on real-time market data."
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Join Us Section */}
        <section className="py-16 bg-premium-green text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Join the Agricultural Revolution</h2>
            <p className="text-xl opacity-90 mb-8 max-w-3xl mx-auto">
              Whether you're a farmer looking to reach new markets or a buyer seeking fresh, 
              quality produce, SNK Vyapar is here to connect you.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button asChild size="lg" className="bg-white text-premium-green hover:bg-gray-100">
                <Link to="/signup">
                  Sign Up Now
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Link to="/marketplace">
                  Explore Marketplace
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-lg font-medium mb-4">SNK Vyapar</h3>
              <p className="text-gray-400">
                Connecting farmers directly to markets, eliminating middlemen, and ensuring fair prices.
              </p>
              <div className="flex space-x-4 mt-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Twitter size={20} />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Instagram size={20} />
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
                <li><Link to="/marketplace" className="text-gray-400 hover:text-white transition-colors">Marketplace</Link></li>
                <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
                <li><Link to="/login" className="text-gray-400 hover:text-white transition-colors">Login</Link></li>
                <li><Link to="/signup" className="text-gray-400 hover:text-white transition-colors">Sign Up</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Categories</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Fruits</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Vegetables</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Grains</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Spices</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Equipment</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Shipping Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Refund Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>© 2023 SNK Vyapar Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;
