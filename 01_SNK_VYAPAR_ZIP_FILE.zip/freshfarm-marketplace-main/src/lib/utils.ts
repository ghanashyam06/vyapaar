
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Calculate days between two dates
export function daysBetween(date1: Date, date2: Date): number {
  const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
  const diffDays = Math.round(Math.abs((date1.getTime() - date2.getTime()) / oneDay));
  return diffDays;
}

// Calculate remaining shelf life
export function calculateRemainingShelfLife(createdAt: string, shelfLifeDays: number): number {
  const creationDate = new Date(createdAt);
  const currentDate = new Date();
  const daysPassed = daysBetween(creationDate, currentDate);
  return Math.max(0, shelfLifeDays - daysPassed);
}

// Format price in INR
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(price);
}

// Get shelf life status text and color
export function getShelfLifeStatus(currentDays: number, initialDays: number) {
  const percentage = (currentDays / initialDays) * 100;
  
  if (currentDays <= 0) return { text: 'Expired', color: 'bg-fresh-danger text-white' };
  if (percentage <= 30) return { text: `${currentDays} days left`, color: 'bg-fresh-danger/10 text-fresh-danger' };
  if (percentage <= 60) return { text: `${currentDays} days left`, color: 'bg-fresh-warning/10 text-fresh-warning' };
  return { text: `${currentDays} days left`, color: 'bg-fresh/10 text-fresh' };
}

// Truncate text with ellipsis
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

// Mock function to simulate API delay
export function simulateDelay(ms: number = 1000): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
