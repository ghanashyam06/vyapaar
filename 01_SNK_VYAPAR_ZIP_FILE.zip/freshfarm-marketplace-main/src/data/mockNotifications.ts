
import { Notification } from '@/types/notification';

// Mock notification data
export const mockNotifications: Notification[] = [
  {
    id: 1,
    type: 'message',
    title: 'New message from Rajesh Kumar',
    content: 'I\'m interested in your organic tomatoes. Are they still available?',
    time: '10 minutes ago',
    read: false,
    sender: 'Rajesh Kumar',
    senderImg: '/placeholder.svg'
  },
  {
    id: 2,
    type: 'order',
    title: 'Order Confirmed',
    content: 'Your order #ORD-002 has been confirmed and is being processed.',
    time: '2 hours ago',
    read: true
  },
  {
    id: 3, 
    type: 'verification',
    title: 'Verification Status Update',
    content: 'Your verification request is under review. We\'ll update you soon.',
    time: '1 day ago',
    read: true
  },
  {
    id: 4,
    type: 'message',
    title: 'New message from Priya Sharma',
    content: 'Do you offer delivery services for your products?',
    time: '2 days ago',
    read: false,
    sender: 'Priya Sharma',
    senderImg: '/placeholder.svg'
  },
  {
    id: 5,
    type: 'system',
    title: 'Welcome to SNK Vyapar!',
    content: 'Thank you for joining our platform. Start by creating your first listing.',
    time: '1 week ago',
    read: true
  }
];
